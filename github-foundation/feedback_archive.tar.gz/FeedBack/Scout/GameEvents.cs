using UnityEngine;
using System;

/// <summary>
/// Централізована система подій для гри - зменшує зв'язаність між компонентами
/// </summary>
public static class GameEvents
{
    // ===== PLAYER EVENTS =====
    
    /// <summary>
    /// Викликається при зміні здоров'я гравця
    /// int currentHealth, int maxHealth, float healthPercentage
    /// </summary>
    public static Action<int, int, float> OnPlayerHealthChanged;
    
    /// <summary>
    /// Викликається при смерті гравця
    /// </summary>
    public static Action OnPlayerDied;
    
    /// <summary>
    /// Викликається при відродженні гравця
    /// Vector3 spawnPosition
    /// </summary>
    public static Action<Vector3> OnPlayerRespawned;
    
    /// <summary>
    /// Викликається при лікуванні гравця
    /// int healAmount, int newHealth
    /// </summary>
    public static Action<int, int> OnPlayerHealed;
    
    /// <summary>
    /// Викликається при отриманні урону гравцем
    /// int damage, int remainingHealth, GameObject source
    /// </summary>
    public static Action<int, int, GameObject> OnPlayerDamaged;
    
    // ===== WEAPON EVENTS =====
    
    /// <summary>
    /// Викликається при зміні патронів
    /// int currentAmmo, int maxAmmo, string weaponName
    /// </summary>
    public static Action<int, int, string> OnAmmoChanged;
    
    /// <summary>
    /// Викликається при початку перезарядки
    /// float reloadTime, string weaponName
    /// </summary>
    public static Action<float, string> OnReloadStarted;
    
    /// <summary>
    /// Викликається при завершенні перезарядки
    /// string weaponName
    /// </summary>
    public static Action<string> OnReloadCompleted;
    
    /// <summary>
    /// Викликається при зміні зброї
    /// string newWeaponName, string oldWeaponName
    /// </summary>
    public static Action<string, string> OnWeaponSwitched;
    
    /// <summary>
    /// Викликається при пострілі
    /// Vector3 shootPosition, Vector3 shootDirection, string weaponName
    /// </summary>
    public static Action<Vector3, Vector3, string> OnWeaponFired;
    
    /// <summary>
    /// Викликається при зміні режиму прицілювання
    /// bool isAiming, string weaponName
    /// </summary>
    public static Action<bool, string> OnAimingChanged;
    
    // ===== GAME STATE EVENTS =====
    
    /// <summary>
    /// Викликається при зміні стану гри
    /// GameState newState, GameState previousState
    /// </summary>
    public static Action<GameState, GameState> OnGameStateChanged;
    
    /// <summary>
    /// Викликається при паузі/відновленні гри
    /// bool isPaused
    /// </summary>
    public static Action<bool> OnGamePaused;
    
    /// <summary>
    /// Викликається при досягненні чекпоінту
    /// string checkpointId, Vector3 checkpointPosition
    /// </summary>
    public static Action<string, Vector3> OnCheckpointReached;
    
    // ===== INTERACTION EVENTS =====
    
    /// <summary>
    /// Викликається при взаємодії з об'єктом
    /// GameObject interactedObject, GameObject player
    /// </summary>
    public static Action<GameObject, GameObject> OnObjectInteracted;
    
    /// <summary>
    /// Викликається при підборі предмета
    /// string itemName, int quantity, GameObject player
    /// </summary>
    public static Action<string, int, GameObject> OnItemPickedUp;
    
    /// <summary>
    /// Викликається при відкритті дверей
    /// GameObject door, bool isOpen
    /// </summary>
    public static Action<GameObject, bool> OnDoorStateChanged;
    
    // ===== UI EVENTS =====
    
    /// <summary>
    /// Викликається для показу/приховування курсора
    /// bool showCursor
    /// </summary>
    public static Action<bool> OnCursorVisibilityChanged;
    
    /// <summary>
    /// Викликається для показу повідомлення гравцю
    /// string message, float duration, MessageType type
    /// </summary>
    public static Action<string, float, MessageType> OnShowPlayerMessage;
    
    /// <summary>
    /// Викликається для оновлення підказки взаємодії
    /// string promptText, bool isVisible
    /// </summary>
    public static Action<string, bool> OnInteractionPromptUpdated;
    
    // ===== AUDIO EVENTS =====
    
    /// <summary>
    /// Викликається для відтворення звукового ефекту
    /// string soundName, Vector3 position, float volume
    /// </summary>
    public static Action<string, Vector3, float> OnPlaySoundEffect;
    
    /// <summary>
    /// Викликається для зміни фонової музики
    /// string musicName, bool fadeTransition
    /// </summary>
    public static Action<string, bool> OnBackgroundMusicChanged;
    
    // ===== CAMERA EFFECTS EVENTS =====
    
    /// <summary>
    /// Викликається для тряски камери
    /// float duration, float magnitude
    /// </summary>
    public static Action<float, float> OnCameraShakeRequested;
    
    /// <summary>
    /// Викликається для ефекту урону на екрані
    /// </summary>
    public static Action OnDamageEffectRequested;
    
    /// <summary>
    /// Викликається для ефекту лікування на екрані
    /// </summary>
    public static Action OnHealEffectRequested;
    
    // ===== UTILITY METHODS =====
    
    /// <summary>
    /// Очищає всі підписки на події (корисно при перезавантаженні сцени)
    /// </summary>
    public static void ClearAllEvents()
    {
        OnPlayerHealthChanged = null;
        OnPlayerDied = null;
        OnPlayerRespawned = null;
        OnPlayerHealed = null;
        OnPlayerDamaged = null;
        
        OnAmmoChanged = null;
        OnReloadStarted = null;
        OnReloadCompleted = null;
        OnWeaponSwitched = null;
        OnWeaponFired = null;
        OnAimingChanged = null;
        
        OnGameStateChanged = null;
        OnGamePaused = null;
        OnCheckpointReached = null;
        
        OnObjectInteracted = null;
        OnItemPickedUp = null;
        OnDoorStateChanged = null;
        
        OnCursorVisibilityChanged = null;
        OnShowPlayerMessage = null;
        OnInteractionPromptUpdated = null;
        
        OnPlaySoundEffect = null;
        OnBackgroundMusicChanged = null;
        
        OnCameraShakeRequested = null;
        OnDamageEffectRequested = null;
        OnHealEffectRequested = null;
        
        Debug.Log("GameEvents: Всі події очищено.");
    }
    
    /// <summary>
    /// Безпечно викликає подію (перевіряє на null)
    /// </summary>
    public static void SafeInvoke<T>(Action<T> action, T parameter)
    {
        try
        {
            action?.Invoke(parameter);
        }
        catch (Exception e)
        {
            Debug.LogError($"Помилка при виклику події: {e.Message}");
        }
    }
    
    /// <summary>
    /// Безпечно викликає подію з двома параметрами
    /// </summary>
    public static void SafeInvoke<T1, T2>(Action<T1, T2> action, T1 param1, T2 param2)
    {
        try
        {
            action?.Invoke(param1, param2);
        }
        catch (Exception e)
        {
            Debug.LogError($"Помилка при виклику події: {e.Message}");
        }
    }
    
    /// <summary>
    /// Безпечно викликає подію з трьома параметрами
    /// </summary>
    public static void SafeInvoke<T1, T2, T3>(Action<T1, T2, T3> action, T1 param1, T2 param2, T3 param3)
    {
        try
        {
            action?.Invoke(param1, param2, param3);
        }
        catch (Exception e)
        {
            Debug.LogError($"Помилка при виклику події: {e.Message}");
        }
    }
    
    /// <summary>
    /// Безпечно викликає подію без параметрів
    /// </summary>
    public static void SafeInvoke(Action action)
    {
        try
        {
            action?.Invoke();
        }
        catch (Exception e)
        {
            Debug.LogError($"Помилка при виклику події: {e.Message}");
        }
    }
}

/// <summary>
/// Енумерація станів гри
/// </summary>
public enum GameState
{
    MainMenu,
    Loading,
    Playing,
    Paused,
    GameOver,
    Victory,
    Settings
}

/// <summary>
/// Типи повідомлень для UI
/// </summary>
public enum MessageType
{
    Info,
    Warning,
    Error,
    Success,
    Achievement
}
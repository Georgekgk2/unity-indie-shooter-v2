using UnityEngine;
using System.Collections.Generic;
using System;

/// <summary>
/// Менеджер для оптимізації Update() викликів - дозволяє контролювати частоту оновлень різних систем
/// </summary>
public class UpdateManager : MonoBehaviour
{
    [Header("Update Frequency Settings")]
    [Tooltip("Основна частота оновлень (разів на секунду)")]
    [Range(10, 120)]
    public float baseUpdateRate = 60f;
    [Tooltip("Повільна частота оновлень для неважливих систем")]
    [Range(1, 30)]
    public float slowUpdateRate = 10f;
    [Tooltip("Дуже повільна частота для рідкісних перевірок")]
    [Range(0.1f, 5f)]
    public float verySlowUpdateRate = 1f;

    // Інтерфейси для різних типів оновлень
    public interface IUpdatable
    {
        void OnUpdate(float deltaTime);
    }

    public interface ISlowUpdatable
    {
        void OnSlowUpdate(float deltaTime);
    }

    public interface IVerySlowUpdatable
    {
        void OnVerySlowUpdate(float deltaTime);
    }

    // Списки об'єктів для оновлення
    private List<IUpdatable> updatables = new List<IUpdatable>();
    private List<ISlowUpdatable> slowUpdatables = new List<ISlowUpdatable>();
    private List<IVerySlowUpdatable> verySlowUpdatables = new List<IVerySlowUpdatable>();

    // Таймери
    private float slowUpdateTimer = 0f;
    private float verySlowUpdateTimer = 0f;
    private float slowUpdateInterval;
    private float verySlowUpdateInterval;

    // Singleton
    public static UpdateManager Instance { get; private set; }

    void Awake()
    {
        if (Instance != null && Instance != this)
        {
            Destroy(gameObject);
            return;
        }
        Instance = this;
        DontDestroyOnLoad(gameObject);

        // Обчислюємо інтервали
        slowUpdateInterval = 1f / slowUpdateRate;
        verySlowUpdateInterval = 1f / verySlowUpdateRate;
    }

    void Update()
    {
        float deltaTime = Time.deltaTime;

        // Основні оновлення (кожен кадр)
        for (int i = updatables.Count - 1; i >= 0; i--)
        {
            if (updatables[i] != null)
            {
                try
                {
                    updatables[i].OnUpdate(deltaTime);
                }
                catch (Exception e)
                {
                    Debug.LogError($"UpdateManager: Помилка в OnUpdate: {e.Message}");
                }
            }
            else
            {
                updatables.RemoveAt(i);
            }
        }

        // Повільні оновлення
        slowUpdateTimer += deltaTime;
        if (slowUpdateTimer >= slowUpdateInterval)
        {
            float slowDeltaTime = slowUpdateTimer;
            slowUpdateTimer = 0f;

            for (int i = slowUpdatables.Count - 1; i >= 0; i--)
            {
                if (slowUpdatables[i] != null)
                {
                    try
                    {
                        slowUpdatables[i].OnSlowUpdate(slowDeltaTime);
                    }
                    catch (Exception e)
                    {
                        Debug.LogError($"UpdateManager: Помилка в OnSlowUpdate: {e.Message}");
                    }
                }
                else
                {
                    slowUpdatables.RemoveAt(i);
                }
            }
        }

        // Дуже повільні оновлення
        verySlowUpdateTimer += deltaTime;
        if (verySlowUpdateTimer >= verySlowUpdateInterval)
        {
            float verySlowDeltaTime = verySlowUpdateTimer;
            verySlowUpdateTimer = 0f;

            for (int i = verySlowUpdatables.Count - 1; i >= 0; i--)
            {
                if (verySlowUpdatables[i] != null)
                {
                    try
                    {
                        verySlowUpdatables[i].OnVerySlowUpdate(verySlowDeltaTime);
                    }
                    catch (Exception e)
                    {
                        Debug.LogError($"UpdateManager: Помилка в OnVerySlowUpdate: {e.Message}");
                    }
                }
                else
                {
                    verySlowUpdatables.RemoveAt(i);
                }
            }
        }
    }

    /// <summary>
    /// Реєструє об'єкт для основних оновлень
    /// </summary>
    public void RegisterUpdatable(IUpdatable updatable)
    {
        if (updatable != null && !updatables.Contains(updatable))
        {
            updatables.Add(updatable);
        }
    }

    /// <summary>
    /// Реєструє об'єкт для повільних оновлень
    /// </summary>
    public void RegisterSlowUpdatable(ISlowUpdatable slowUpdatable)
    {
        if (slowUpdatable != null && !slowUpdatables.Contains(slowUpdatable))
        {
            slowUpdatables.Add(slowUpdatable);
        }
    }

    /// <summary>
    /// Реєструє об'єкт для дуже повільних оновлень
    /// </summary>
    public void RegisterVerySlowUpdatable(IVerySlowUpdatable verySlowUpdatable)
    {
        if (verySlowUpdatable != null && !verySlowUpdatables.Contains(verySlowUpdatable))
        {
            verySlowUpdatables.Add(verySlowUpdatable);
        }
    }

    /// <summary>
    /// Видаляє об'єкт з основних оновлень
    /// </summary>
    public void UnregisterUpdatable(IUpdatable updatable)
    {
        updatables.Remove(updatable);
    }

    /// <summary>
    /// Видаляє об'єкт з повільних оновлень
    /// </summary>
    public void UnregisterSlowUpdatable(ISlowUpdatable slowUpdatable)
    {
        slowUpdatables.Remove(slowUpdatable);
    }

    /// <summary>
    /// Видаляє об'єкт з дуже повільних оновлень
    /// </summary>
    public void UnregisterVerySlowUpdatable(IVerySlowUpdatable verySlowUpdatable)
    {
        verySlowUpdatables.Remove(verySlowUpdatable);
    }

    /// <summary>
    /// Змінює частоту повільних оновлень
    /// </summary>
    public void SetSlowUpdateRate(float newRate)
    {
        slowUpdateRate = Mathf.Clamp(newRate, 1f, 30f);
        slowUpdateInterval = 1f / slowUpdateRate;
    }

    /// <summary>
    /// Змінює частоту дуже повільних оновлень
    /// </summary>
    public void SetVerySlowUpdateRate(float newRate)
    {
        verySlowUpdateRate = Mathf.Clamp(newRate, 0.1f, 5f);
        verySlowUpdateInterval = 1f / verySlowUpdateRate;
    }

    /// <summary>
    /// Повертає статистику UpdateManager
    /// </summary>
    public void PrintStatistics()
    {
        Debug.Log($"UpdateManager Statistics:\n" +
                  $"- Regular Updates: {updatables.Count}\n" +
                  $"- Slow Updates: {slowUpdatables.Count} (rate: {slowUpdateRate}/s)\n" +
                  $"- Very Slow Updates: {verySlowUpdatables.Count} (rate: {verySlowUpdateRate}/s)\n" +
                  $"- Total Managed Objects: {updatables.Count + slowUpdatables.Count + verySlowUpdatables.Count}");
    }

    // Властивості для отримання статистики
    public int RegularUpdatesCount => updatables.Count;
    public int SlowUpdatesCount => slowUpdatables.Count;
    public int VerySlowUpdatesCount => verySlowUpdatables.Count;
}

/// <summary>
/// Допоміжний клас для легкої реєстрації в UpdateManager
/// </summary>
public abstract class ManagedBehaviour : MonoBehaviour, UpdateManager.IUpdatable, UpdateManager.ISlowUpdatable, UpdateManager.IVerySlowUpdatable
{
    [Header("Update Management")]
    [Tooltip("Використовувати основні оновлення")]
    public bool useRegularUpdate = true;
    [Tooltip("Використовувати повільні оновлення")]
    public bool useSlowUpdate = false;
    [Tooltip("Використовувати дуже повільні оновлення")]
    public bool useVerySlowUpdate = false;

    protected virtual void Start()
    {
        if (UpdateManager.Instance != null)
        {
            if (useRegularUpdate) UpdateManager.Instance.RegisterUpdatable(this);
            if (useSlowUpdate) UpdateManager.Instance.RegisterSlowUpdatable(this);
            if (useVerySlowUpdate) UpdateManager.Instance.RegisterVerySlowUpdatable(this);
        }
    }

    protected virtual void OnDestroy()
    {
        if (UpdateManager.Instance != null)
        {
            UpdateManager.Instance.UnregisterUpdatable(this);
            UpdateManager.Instance.UnregisterSlowUpdatable(this);
            UpdateManager.Instance.UnregisterVerySlowUpdatable(this);
        }
    }

    // Віртуальні методи для перевизначення
    public virtual void OnUpdate(float deltaTime) { }
    public virtual void OnSlowUpdate(float deltaTime) { }
    public virtual void OnVerySlowUpdate(float deltaTime) { }
}
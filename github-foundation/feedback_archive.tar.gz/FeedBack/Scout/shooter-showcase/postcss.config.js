export default {
  plugins: {
    autoprefixer: {},
  },
};
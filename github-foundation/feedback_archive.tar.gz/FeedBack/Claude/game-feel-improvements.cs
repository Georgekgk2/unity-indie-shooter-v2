// HitFeedback.cs - Система фідбеку при влучанні
using UnityEngine;
using System.Collections;

public class HitFeedback : MonoBehaviour
{
    [Header("Hit Marker")]
    [SerializeField] private GameObject hitMarkerPrefab;
    [SerializeField] private float hitMarkerDuration = 0.2f;
    [SerializeField] private AudioClip hitSound;
    [SerializeField] private AudioClip headshotSound;
    
    [Header("Damage Numbers")]
    [SerializeField] private GameObject damageNumberPrefab;
    [SerializeField] private Color normalDamageColor = Color.white;
    [SerializeField] private Color criticalDamageColor = Color.red;
    
    [Header("Screen Effects")]
    [SerializeField] private float hitStopDuration = 0.05f;
    
    private Camera playerCamera;
    private AudioSource audioSource;
    
    void Start()
    {
        playerCamera = Camera.main;
        audioSource = GetComponent<AudioSource>();
        
        // Підписуємося на події урону
        HealthSystem.OnAnyDamageTaken += HandleHitFeedback;
    }
    
    void OnDestroy()
    {
        HealthSystem.OnAnyDamageTaken -= HandleHitFeedback;
    }
    
    private void HandleHitFeedback(GameObject target, float damage)
    {
        // Перевіряємо, чи це наше влучання
        if (IsOurHit(target))
        {
            ShowHitMarker();
            ShowDamageNumber(target.transform.position, damage);
            PlayHitSound(target.CompareTag("EnemyHead"));
            StartCoroutine(HitStop());
        }
    }
    
    private void ShowHitMarker()
    {
        if (hitMarkerPrefab != null)
        {
            GameObject marker = Instantiate(hitMarkerPrefab, transform);
            Destroy(marker, hitMarkerDuration);
        }
    }
    
    private void ShowDamageNumber(Vector3 worldPosition, float damage)
    {
        if (damageNumberPrefab != null)
        {
            GameObject damageNum = Instantiate(damageNumberPrefab, worldPosition, Quaternion.identity);
            
            // Налаштовуємо текст та колір
            var textComponent = damageNum.GetComponent<TMPro.TextMeshPro>();
            if (textComponent != null)
            {
                textComponent.text = damage.ToString("0");
                textComponent.color = damage > 50 ? criticalDamageColor : normalDamageColor;
            }
            
            // Анімація підйому та зникнення
            StartCoroutine(AnimateDamageNumber(damageNum));
        }
    }
    
    private IEnumerator AnimateDamageNumber(GameObject damageNumber)
    {
        float duration = 1f;
        float elapsed = 0f;
        Vector3 startPos = damageNumber.transform.position;
        
        while (elapsed < duration)
        {
            elapsed += Time.deltaTime;
            float progress = elapsed / duration;
            
            // Рух вгору з уповільненням
            damageNumber.transform.position = startPos + Vector3.up * (2f * progress * (1 - progress));
            
            // Зникнення
            var textComponent = damageNumber.GetComponent<TMPro.TextMeshPro>();
            if (textComponent != null)
            {
                Color color = textComponent.color;
                color.a = 1f - progress;
                textComponent.color = color;
            }
            
            yield return null;
        }
        
        Destroy(damageNumber);
    }
    
    private void PlayHitSound(bool isHeadshot)
    {
        if (audioSource != null)
        {
            AudioClip clipToPlay = isHeadshot ? headshotSound : hitSound;
            if (clipToPlay != null)
            {
                audioSource.PlayOneShot(clipToPlay);
            }
        }
    }
    
    private IEnumerator HitStop()
    {
        Time.timeScale = 0.1f;
        yield return new WaitForSecondsRealtime(hitStopDuration);
        Time.timeScale = 1f;
    }
    
    private bool IsOurHit(GameObject target)
    {
        // Логіка перевірки, чи це наше влучання
        return target.CompareTag("Enemy");
    }
}

// WeaponFeelEnhancer.cs - Покращення відчуття зброї
public class WeaponFeelEnhancer : MonoBehaviour
{
    [Header("Muzzle Flash")]
    [SerializeField] private Light muzzleFlashLight;
    [SerializeField] private float lightIntensity = 5f;
    [SerializeField] private float lightDuration = 0.05f;
    
    [Header("Shell Ejection")]
    [SerializeField] private GameObject shellPrefab;
    [SerializeField] private Transform ejectionPort;
    [SerializeField] private float ejectionForce = 5f;
    
    [Header("Weapon Kick")]
    [SerializeField] private float kickAmount = 0.1f;
    [SerializeField] private float kickSpeed = 20f;
    
    private Vector3 originalPosition;
    private WeaponController weaponController;
    
    void Start()
    {
        originalPosition = transform.localPosition;
        weaponController = GetComponent<WeaponController>();
        
        // Створюємо динамічне світло для спалаху
        if (muzzleFlashLight == null)
        {
            GameObject lightObj = new GameObject("MuzzleFlashLight");
            lightObj.transform.SetParent(transform);
            lightObj.transform.localPosition = Vector3.forward * 0.5f;
            muzzleFlashLight = lightObj.AddComponent<Light>();
            muzzleFlashLight.type = LightType.Point;
            muzzleFlashLight.intensity = 0;
            muzzleFlashLight.range = 10f;
            muzzleFlashLight.color = new Color(1f, 0.8f, 0.4f);
        }
    }
    
    public void OnShoot()
    {
        StartCoroutine(MuzzleFlashEffect());
        EjectShell();
        StartCoroutine(WeaponKick());
    }
    
    private IEnumerator MuzzleFlashEffect()
    {
        muzzleFlashLight.intensity = lightIntensity;
        yield return new WaitForSeconds(lightDuration);
        muzzleFlashLight.intensity = 0;
    }
    
    private void EjectShell()
    {
        if (shellPrefab != null && ejectionPort != null)
        {
            GameObject shell = Instantiate(shellPrefab, ejectionPort.position, ejectionPort.rotation);
            Rigidbody shellRb = shell.GetComponent<Rigidbody>();
            
            if (shellRb != null)
            {
                Vector3 ejectionDirection = ejectionPort.right + Random.insideUnitSphere * 0.3f;
                shellRb.AddForce(ejectionDirection * ejectionForce, ForceMode.Impulse);
                shellRb.AddTorque(Random.insideUnitSphere * 10f, ForceMode.Impulse);
            }
            
            // Знищуємо гільзу через 5 секунд
            Destroy(shell, 5f);
        }
    }
    
    private IEnumerator WeaponKick()
    {
        float elapsed = 0f;
        float duration = 0.1f;
        
        while (elapsed < duration)
        {
            elapsed += Time.deltaTime;
            float progress = elapsed / duration;
            
            // Різкий удар назад, плавне повернення
            float kickCurve = 1f - Mathf.Pow(1f - progress, 3f);
            Vector3 kickOffset = Vector3.back * kickAmount * (1f - kickCurve);
            
            transform.localPosition = originalPosition + kickOffset;
            yield return null;
        }
        
        transform.localPosition = originalPosition;
    }
}
// GameEvents.cs - Центральна система подій
using UnityEngine;
using System;
using System.Collections.Generic;

public static class GameEvents
{
    // Player Events
    public static event Action<float> OnPlayerHealthChanged;
    public static event Action<float> OnPlayerStaminaChanged;
    public static event Action OnPlayerDeath;
    public static event Action OnPlayerRespawn;
    
    // Weapon Events
    public static event Action<WeaponConfig> OnWeaponEquipped;
    public static event Action<WeaponConfig> OnWeaponUnequipped;
    public static event Action<int, int> OnAmmoChanged; // current, max
    public static event Action OnReloadStarted;
    public static event Action OnReloadFinished;
    
    // Combat Events
    public static event Action<GameObject, float> OnDamageDealt;
    public static event Action<GameObject> OnEnemyKilled;
    public static event Action<int> OnComboIncreased;
    
    // Game State Events
    public static event Action OnGamePaused;
    public static event Action OnGameResumed;
    public static event Action<string> OnCheckpointReached;
    
    // Методи для виклику подій
    public static void TriggerPlayerHealthChanged(float health) => OnPlayerHealthChanged?.Invoke(health);
    public static void TriggerPlayerStaminaChanged(float stamina) => OnPlayerStaminaChanged?.Invoke(stamina);
    public static void TriggerPlayerDeath() => OnPlayerDeath?.Invoke();
    public static void TriggerPlayerRespawn() => OnPlayerRespawn?.Invoke();
    
    public static void TriggerWeaponEquipped(WeaponConfig config) => OnWeaponEquipped?.Invoke(config);
    public static void TriggerWeaponUnequipped(WeaponConfig config) => OnWeaponUnequipped?.Invoke(config);
    public static void TriggerAmmoChanged(int current, int max) => OnAmmoChanged?.Invoke(current, max);
    
    // Очищення всіх підписок (важливо при зміні сцен)
    public static void ClearAllEvents()
    {
        OnPlayerHealthChanged = null;
        OnPlayerStaminaChanged = null;
        OnPlayerDeath = null;
        OnPlayerRespawn = null;
        OnWeaponEquipped = null;
        OnWeaponUnequipped = null;
        OnAmmoChanged = null;
        OnReloadStarted = null;
        OnReloadFinished = null;
        OnDamageDealt = null;
        OnEnemyKilled = null;
        OnComboIncreased = null;
        OnGamePaused = null;
        OnGameResumed = null;
        OnCheckpointReached = null;
    }
}

// EventBus.cs - Альтернативна система з типізованими подіями
public class EventBus : MonoBehaviour
{
    private static EventBus instance;
    private Dictionary<Type, List<object>> subscribers = new Dictionary<Type, List<object>>();
    
    public static EventBus Instance
    {
        get
        {
            if (instance == null)
            {
                GameObject go = new GameObject("EventBus");
                instance = go.AddComponent<EventBus>();
                DontDestroyOnLoad(go);
            }
            return instance;
        }
    }
    
    public void Subscribe<T>(Action<T> callback) where T : IGameEvent
    {
        Type eventType = typeof(T);
        
        if (!subscribers.ContainsKey(eventType))
            subscribers[eventType] = new List<object>();
            
        subscribers[eventType].Add(callback);
    }
    
    public void Unsubscribe<T>(Action<T> callback) where T : IGameEvent
    {
        Type eventType = typeof(T);
        
        if (subscribers.ContainsKey(eventType))
            subscribers[eventType].Remove(callback);
    }
    
    public void Publish<T>(T gameEvent) where T : IGameEvent
    {
        Type eventType = typeof(T);
        
        if (subscribers.ContainsKey(eventType))
        {
            foreach (var subscriber in subscribers[eventType])
            {
                (subscriber as Action<T>)?.Invoke(gameEvent);
            }
        }
    }
}

// Інтерфейс для всіх ігрових подій
public interface IGameEvent { }

// Приклади типізованих подій
public struct PlayerDamagedEvent : IGameEvent
{
    public float Damage;
    public GameObject Source;
    public Vector3 HitPoint;
    
    public PlayerDamagedEvent(float damage, GameObject source, Vector3 hitPoint)
    {
        Damage = damage;
        Source = source;
        HitPoint = hitPoint;
    }
}

public struct WeaponFiredEvent : IGameEvent
{
    public WeaponConfig Weapon;
    public Vector3 Origin;
    public Vector3 Direction;
    
    public WeaponFiredEvent(WeaponConfig weapon, Vector3 origin, Vector3 direction)
    {
        Weapon = weapon;
        Origin = origin;
        Direction = direction;
    }
}

// UIManager.cs - Приклад використання подій
public class UIManager : MonoBehaviour
{
    [SerializeField] private TMPro.TextMeshProUGUI healthText;
    [SerializeField] private TMPro.TextMeshProUGUI ammoText;
    [SerializeField] private Image staminaBar;
    
    void OnEnable()
    {
        // Підписка на події
        GameEvents.OnPlayerHealthChanged += UpdateHealthUI;
        GameEvents.OnPlayerStaminaChanged += UpdateStaminaUI;
        GameEvents.OnAmmoChanged += UpdateAmmoUI;
        
        // Або через EventBus
        EventBus.Instance.Subscribe<PlayerDamagedEvent>(OnPlayerDamaged);
    }
    
    void OnDisable()
    {
        // Відписка від подій
        GameEvents.OnPlayerHealthChanged -= UpdateHealthUI;
        GameEvents.OnPlayerStaminaChanged -= UpdateStaminaUI;
        GameEvents.OnAmmoChanged -= UpdateAmmoUI;
        
        EventBus.Instance.Unsubscribe<PlayerDamagedEvent>(OnPlayerDamaged);
    }
    
    private void UpdateHealthUI(float health)
    {
        if (healthText != null)
            healthText.text = $"HP: {health:0}";
    }
    
    private void UpdateStaminaUI(float stamina)
    {
        if (staminaBar != null)
            staminaBar.fillAmount = stamina;
    }
    
    private void UpdateAmmoUI(int current, int max)
    {
        if (ammoText != null)
            ammoText.text = $"{current}/{max}";
    }
    
    private void OnPlayerDamaged(PlayerDamagedEvent e)
    {
        // Показати індикатор напрямку урону
        ShowDamageIndicator(e.HitPoint);
    }
    
    private void ShowDamageIndicator(Vector3 damageSource)
    {
        // Логіка відображення індикатора
    }
}
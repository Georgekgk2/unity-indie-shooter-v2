using UnityEngine;
using System.Collections;

/// <summary>
/// Компонент, який додається до куль для автоматичного повернення в пул
/// </summary>
public class BulletPoolItem : MonoBehaviour
{
    [Header("Auto Return Settings")]
    [Tooltip("Чи повертатися автоматично в пул через певний час")]
    public bool useAutoReturn = true;
    [Tooltip("Час життя кулі (перевизначає налаштування пулу)")]
    public float customLifetime = -1f; // -1 означає використання налаштувань пулу

    private Coroutine autoReturnCoroutine;
    private bool hasCollided = false;

    void OnEnable()
    {
        // Скидаємо стан при активації
        hasCollided = false;
        
        // Якщо налаштовано автоповернення, запускаємо таймер
        if (useAutoReturn)
        {
            float lifetime = customLifetime > 0 ? customLifetime : 
                           (BulletPool.Instance?.bulletLifetime ?? 10f);
            SetupAutoReturn(lifetime);
        }
    }

    void OnDisable()
    {
        // Зупиняємо корутину при деактивації
        if (autoReturnCoroutine != null)
        {
            StopCoroutine(autoReturnCoroutine);
            autoReturnCoroutine = null;
        }
    }

    /// <summary>
    /// Налаштовує автоматичне повернення в пул
    /// </summary>
    public void SetupAutoReturn(float lifetime)
    {
        if (autoReturnCoroutine != null)
        {
            StopCoroutine(autoReturnCoroutine);
        }
        autoReturnCoroutine = StartCoroutine(AutoReturnCoroutine(lifetime));
    }

    /// <summary>
    /// Корутина для автоматичного повернення
    /// </summary>
    private IEnumerator AutoReturnCoroutine(float lifetime)
    {
        yield return new WaitForSeconds(lifetime);
        ReturnToPool();
    }

    /// <summary>
    /// Обробка зіткнень кулі
    /// </summary>
    void OnTriggerEnter(Collider other)
    {
        HandleCollision(other.gameObject);
    }

    void OnCollisionEnter(Collision collision)
    {
        HandleCollision(collision.gameObject);
    }

    /// <summary>
    /// Обробляє зіткнення кулі
    /// </summary>
    private void HandleCollision(GameObject hitObject)
    {
        if (hasCollided) return; // Запобігаємо множинним зіткненням
        hasCollided = true;

        // Тут можна додати логіку завдання урону, ефектів тощо
        // Наприклад:
        // PlayerHealth playerHealth = hitObject.GetComponent<PlayerHealth>();
        // if (playerHealth != null) playerHealth.TakeDamage(damage);

        // Можна додати ефекти попадання
        CreateHitEffect(transform.position);

        // Повертаємо кулю в пул з невеликою затримкою для ефектів
        StartCoroutine(DelayedReturn(0.1f));
    }

    /// <summary>
    /// Створює ефект попадання (можна розширити)
    /// </summary>
    private void CreateHitEffect(Vector3 position)
    {
        // Тут можна додати частинки, звуки тощо
        // Наприклад:
        // if (hitEffectPrefab != null)
        // {
        //     GameObject effect = Instantiate(hitEffectPrefab, position, Quaternion.identity);
        //     Destroy(effect, 2f);
        // }
    }

    /// <summary>
    /// Повертає кулю в пул з затримкою
    /// </summary>
    private IEnumerator DelayedReturn(float delay)
    {
        yield return new WaitForSeconds(delay);
        ReturnToPool();
    }

    /// <summary>
    /// Повертає кулю в пул
    /// </summary>
    public void ReturnToPool()
    {
        if (BulletPool.Instance != null)
        {
            BulletPool.Instance.ReturnBullet(gameObject);
        }
        else
        {
            // Якщо пул недоступний, просто знищуємо об'єкт
            Debug.LogWarning("BulletPoolItem: BulletPool недоступний, знищую кулю.");
            Destroy(gameObject);
        }
    }

    /// <summary>
    /// Примусово повертає кулю в пул (викликається ззовні)
    /// </summary>
    public void ForceReturn()
    {
        hasCollided = true; // Запобігаємо подальшим зіткненням
        ReturnToPool();
    }

    /// <summary>
    /// Встановлює час життя кулі
    /// </summary>
    public void SetLifetime(float lifetime)
    {
        customLifetime = lifetime;
        if (gameObject.activeInHierarchy && useAutoReturn)
        {
            SetupAutoReturn(lifetime);
        }
    }

    /// <summary>
    /// Перевіряє, чи куля вже зіткнулася
    /// </summary>
    public bool HasCollided()
    {
        return hasCollided;
    }
}
using UnityEngine;
using System.Collections.Generic;
using System.Collections;

/// <summary>
/// Система Object Pool для куль - оптимізує продуктивність шляхом повторного використання об'єктів
/// замість постійного створення та знищення
/// </summary>
public class BulletPool : MonoBehaviour
{
    [Header("Pool Settings")]
    [Tooltip("Префаб кулі для пулу")]
    public GameObject bulletPrefab;
    [Tooltip("Початковий розмір пулу")]
    [Range(10, 200)]
    public int initialPoolSize = 50;
    [Tooltip("Максимальний розмір пулу (0 = необмежений)")]
    [Range(0, 500)]
    public int maxPoolSize = 100;
    [Tooltip("Чи розширювати пул автоматично, якщо куль не вистачає")]
    public bool autoExpand = true;
    
    [Header("Auto-Return Settings")]
    [Tooltip("Автоматично повертати кулі в пул через певний час")]
    public bool useAutoReturn = true;
    [Tooltip("Час життя кулі в секундах (після цього вона автоматично повернеться в пул)")]
    [Range(1f, 30f)]
    public float bulletLifetime = 10f;
    
    [Header("Debug Settings")]
    [Tooltip("Показувати інформацію про пул в консолі")]
    public bool enableDebugLogging = false;

    // Приватні змінні
    private Queue<GameObject> bulletPool;
    private List<GameObject> activeBullets; // Для відстеження активних куль
    private Transform poolParent; // Батьківський об'єкт для організації
    private int bulletsCreated = 0; // Статистика
    private int bulletsReused = 0; // Статистика

    // Singleton pattern для глобального доступу
    public static BulletPool Instance { get; private set; }

    void Awake()
    {
        // Реалізація Singleton
        if (Instance != null && Instance != this)
        {
            Destroy(gameObject);
            return;
        }
        Instance = this;
        
        // Ініціалізація
        InitializePool();
    }

    void OnDestroy()
    {
        if (Instance == this)
        {
            Instance = null;
        }
    }

    /// <summary>
    /// Ініціалізує пул куль
    /// </summary>
    private void InitializePool()
    {
        if (bulletPrefab == null)
        {
            Debug.LogError("BulletPool: Bullet Prefab не призначено! Пул не буде працювати.");
            enabled = false;
            return;
        }

        // Створюємо контейнери
        bulletPool = new Queue<GameObject>();
        activeBullets = new List<GameObject>();

        // Створюємо батьківський об'єкт для організації ієрархії
        GameObject poolContainer = new GameObject("BulletPool_Container");
        poolContainer.transform.SetParent(transform);
        poolParent = poolContainer.transform;

        // Попередньо створюємо кулі
        for (int i = 0; i < initialPoolSize; i++)
        {
            GameObject bullet = CreateNewBullet();
            bullet.SetActive(false);
            bulletPool.Enqueue(bullet);
        }

        if (enableDebugLogging)
        {
            Debug.Log($"BulletPool: Ініціалізовано з {initialPoolSize} кулями.");
        }
    }

    /// <summary>
    /// Створює нову кулю
    /// </summary>
    private GameObject CreateNewBullet()
    {
        GameObject bullet = Instantiate(bulletPrefab, poolParent);
        bulletsCreated++;
        
        // Переконуємося, що у кулі є BulletPoolItem компонент
        if (bullet.GetComponent<BulletPoolItem>() == null)
        {
            bullet.AddComponent<BulletPoolItem>();
        }

        return bullet;
    }

    /// <summary>
    /// Отримує кулю з пулу
    /// </summary>
    public GameObject GetBullet()
    {
        GameObject bullet = null;

        // Спробуємо взяти з пулу
        if (bulletPool.Count > 0)
        {
            bullet = bulletPool.Dequeue();
            bulletsReused++;
        }
        // Якщо пул порожній, створюємо нову (якщо дозволено)
        else if (autoExpand && (maxPoolSize == 0 || activeBullets.Count < maxPoolSize))
        {
            bullet = CreateNewBullet();
            if (enableDebugLogging)
            {
                Debug.Log($"BulletPool: Пул розширено. Нових куль створено: {bulletsCreated}");
            }
        }

        // Якщо отримали кулю, активуємо її
        if (bullet != null)
        {
            bullet.SetActive(true);
            activeBullets.Add(bullet);

            // Налаштовуємо автоповернення
            if (useAutoReturn)
            {
                BulletPoolItem poolItem = bullet.GetComponent<BulletPoolItem>();
                if (poolItem != null)
                {
                    poolItem.SetupAutoReturn(bulletLifetime);
                }
            }

            if (enableDebugLogging)
            {
                Debug.Log($"BulletPool: Куля взята з пулу. Активних: {activeBullets.Count}, В пулі: {bulletPool.Count}");
            }
        }
        else
        {
            Debug.LogWarning("BulletPool: Не вдалося отримати кулю! Пул вичерпано і розширення заборонено.");
        }

        return bullet;
    }

    /// <summary>
    /// Повертає кулю в пул
    /// </summary>
    public void ReturnBullet(GameObject bullet)
    {
        if (bullet == null) return;

        // Прибираємо з активних
        if (activeBullets.Contains(bullet))
        {
            activeBullets.Remove(bullet);
        }

        // Скидаємо стан кулі
        ResetBullet(bullet);

        // Повертаємо в пул, якщо не перевищено максимальний розмір
        if (maxPoolSize == 0 || bulletPool.Count < maxPoolSize)
        {
            bullet.SetActive(false);
            bullet.transform.SetParent(poolParent);
            bulletPool.Enqueue(bullet);

            if (enableDebugLogging)
            {
                Debug.Log($"BulletPool: Куля повернена в пул. Активних: {activeBullets.Count}, В пулі: {bulletPool.Count}");
            }
        }
        else
        {
            // Якщо пул переповнений, знищуємо кулю
            Destroy(bullet);
            if (enableDebugLogging)
            {
                Debug.Log("BulletPool: Куля знищена через переповнення пулу.");
            }
        }
    }

    /// <summary>
    /// Скидає стан кулі перед поверненням в пул
    /// </summary>
    private void ResetBullet(GameObject bullet)
    {
        // Скидаємо фізику
        Rigidbody rb = bullet.GetComponent<Rigidbody>();
        if (rb != null)
        {
            rb.velocity = Vector3.zero;
            rb.angularVelocity = Vector3.zero;
        }

        // Скидаємо позицію та обертання
        bullet.transform.position = Vector3.zero;
        bullet.transform.rotation = Quaternion.identity;

        // Зупиняємо всі корутини
        MonoBehaviour[] components = bullet.GetComponents<MonoBehaviour>();
        foreach (MonoBehaviour component in components)
        {
            if (component != null)
            {
                component.StopAllCoroutines();
            }
        }
    }

    /// <summary>
    /// Примусово повертає всі активні кулі в пул
    /// </summary>
    public void ReturnAllBullets()
    {
        List<GameObject> bulletsToReturn = new List<GameObject>(activeBullets);
        foreach (GameObject bullet in bulletsToReturn)
        {
            ReturnBullet(bullet);
        }

        if (enableDebugLogging)
        {
            Debug.Log($"BulletPool: Всі кулі повернені в пул. Всього повернено: {bulletsToReturn.Count}");
        }
    }

    /// <summary>
    /// Очищає весь пул
    /// </summary>
    public void ClearPool()
    {
        ReturnAllBullets();

        while (bulletPool.Count > 0)
        {
            GameObject bullet = bulletPool.Dequeue();
            if (bullet != null)
            {
                Destroy(bullet);
            }
        }

        bulletPool.Clear();
        activeBullets.Clear();
        bulletsCreated = 0;
        bulletsReused = 0;

        if (enableDebugLogging)
        {
            Debug.Log("BulletPool: Пул очищено.");
        }
    }

    /// <summary>
    /// Статистика пулу
    /// </summary>
    public void PrintPoolStats()
    {
        Debug.Log($"BulletPool Statistics:\n" +
                  $"- Bullets Created: {bulletsCreated}\n" +
                  $"- Bullets Reused: {bulletsReused}\n" +
                  $"- Active Bullets: {activeBullets.Count}\n" +
                  $"- Pooled Bullets: {bulletPool.Count}\n" +
                  $"- Total Pool Size: {activeBullets.Count + bulletPool.Count}\n" +
                  $"- Reuse Rate: {(bulletsReused > 0 ? (float)bulletsReused / (bulletsCreated + bulletsReused) * 100f : 0f):F1}%");
    }

    // Публічні властивості для отримання статистики
    public int ActiveBulletsCount => activeBullets.Count;
    public int PooledBulletsCount => bulletPool.Count;
    public int TotalBulletsCreated => bulletsCreated;
    public int TotalBulletsReused => bulletsReused;

#if UNITY_EDITOR
    // Для налагодження в редакторі
    void OnValidate()
    {
        if (maxPoolSize > 0 && initialPoolSize > maxPoolSize)
        {
            initialPoolSize = maxPoolSize;
        }
    }
#endif
}
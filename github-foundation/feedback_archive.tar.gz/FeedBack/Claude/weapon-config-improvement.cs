// WeaponConfig.cs - ScriptableObject для конфігурації зброї
using UnityEngine;

[CreateAssetMenu(fileName = "New Weapon Config", menuName = "Weapons/Weapon Config")]
public class WeaponConfig : ScriptableObject
{
    [Header("Basic Settings")]
    public string weaponName = "Assault Rifle";
    public Sprite weaponIcon;
    public GameObject weaponPrefab;
    public GameObject bulletPrefab;
    public GameObject worldDropPrefab;
    
    [Header("Shooting")]
    public float fireRate = 8f;
    public float bulletForce = 30f;
    public float bulletSpread = 0.05f;
    public float maxAimDistance = 500f;
    
    [Header("Ammo")]
    public int magazineSize = 30;
    public float reloadTime = 2f;
    public int startingReloadCharges = 3;
    
    [Header("Recoil")]
    public Vector3 recoilAmount = new Vector3(2f, 0.5f, 0.5f);
    public float recoilSnappiness = 10f;
    public float recoilReturnSpeed = 5f;
    
    [Header("ADS Settings")]
    public bool canAim = true;
    public Vector3 aimPosition;
    public float aimFOV = 40f;
    public float aimSpeed = 10f;
    public float aimSpreadMultiplier = 0.5f;
    public float aimRecoilMultiplier = 0.5f;
    
    [Header("Audio")]
    public AudioClip shootSound;
    public AudioClip reloadSound;
    public AudioClip emptyClipSound;
}

// WeaponController.cs - Оновлений початок класу
public class WeaponController : MonoBehaviour
{
    [Header("Weapon Configuration")]
    [SerializeField] private WeaponConfig config;
    
    // Решта полів стають приватними
    private Transform bulletSpawnPoint;
    private ParticleSystem muzzleFlash;
    private AudioSource audioSource;
    
    // Runtime змінні
    private int currentAmmo;
    private float nextFireTime = 0f;
    private bool isReloading = false;
    private int reloadCharges;
    
    void Awake()
    {
        if (config == null)
        {
            Debug.LogError($"WeaponController: No WeaponConfig assigned to {gameObject.name}");
            enabled = false;
            return;
        }
        
        // Ініціалізація з конфігурації
        currentAmmo = config.magazineSize;
        reloadCharges = config.startingReloadCharges;
        
        // Пошук компонентів
        bulletSpawnPoint = transform.Find("BulletSpawnPoint");
        muzzleFlash = GetComponentInChildren<ParticleSystem>();
        audioSource = GetComponent<AudioSource>();
        
        // ... решта ініціалізації
    }
    
    // Приклад використання конфігурації в методі Shoot
    void Shoot()
    {
        nextFireTime = Time.time + 1f / config.fireRate;
        currentAmmo--;
        
        if (audioSource != null && config.shootSound != null)
        {
            audioSource.PlayOneShot(config.shootSound);
        }
        
        // ... решта логіки стрільби з використанням config
    }
}
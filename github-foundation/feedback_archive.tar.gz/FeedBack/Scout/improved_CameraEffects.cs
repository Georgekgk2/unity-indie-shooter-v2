using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class CameraEffects : MonoBehaviour
{
    [Header("Camera Shake Settings")]
    [Tooltip("Стандартна тривалість тряски камери.")]
    public float defaultShakeDuration = 0.2f;
    [Tooltip("Стандартна сила (амплітуда) тряски камери.")]
    public float defaultShakeMagnitude = 0.1f;
    
    [Header("Damage Flash Settings")]
    [Tooltip("Image UI-елемент для червоного спалаху при отриманні урону.")]
    public Image damageFlashImage;
    [Tooltip("Тривалість спалаху (у секундах).")]
    public float flashDuration = 0.25f;
    [Tooltip("Максимальна прозорість спалаху (від 0 до 1).")]
    public float maxFlashAlpha = 0.5f;

    [Header("Heal Effect Settings")]
    [Tooltip("Image UI-елемент для спалаху при лікуванні.")]
    public Image healFlashImage;
    [Tooltip("Тривалість ефекту лікування.")]
    public float healEffectDuration = 0.5f; // Збільшено для кращого ефекту
    [Tooltip("Максимальна прозорість ефекту лікування.")]
    public float maxHealAlpha = 0.4f; // Трохи збільшено
    [Tooltip("Сила тряски камери при лікуванні (0 - без тряски).")]
    public float healShakeMagnitude = 0.03f; // Зменшено для м'якості
    [Tooltip("Кількість пульсацій при лікуванні.")]
    [Range(1, 5)]
    public int healPulseCount = 2; // НОВЕ: пульсації для кращого ефекту
    
    [Header("Low Health Warning Settings")] // НОВИЙ РОЗДІЛ
    [Tooltip("Image UI-елемент для попередження про низьке здоров'я.")]
    public Image lowHealthWarningImage;
    [Tooltip("Поріг здоров'я для активації попередження (у відсотках).")]
    [Range(0.1f, 0.5f)]
    public float lowHealthThreshold = 0.25f; // 25% здоров'я
    [Tooltip("Швидкість пульсації попередження про низьке здоров'я.")]
    public float lowHealthPulseSpeed = 2f;
    [Tooltip("Максимальна прозорість попередження про низьке здоров'я.")]
    public float maxLowHealthAlpha = 0.3f;

    // Приватні змінні
    private Vector3 originalCameraPosition;
    private Coroutine shakeCoroutine;
    private Coroutine damageFlashCoroutine;
    private Coroutine healFlashCoroutine;
    private Coroutine lowHealthWarningCoroutine; // НОВЕ
    private bool isLowHealthWarningActive = false; // НОВЕ

    void Awake()
    {
        originalCameraPosition = transform.localPosition;
        
        // Переконуємося, що спалахи вимкнені при старті
        InitializeFlashImage(damageFlashImage);
        InitializeFlashImage(healFlashImage);
        InitializeFlashImage(lowHealthWarningImage);
    }
    
    /// <summary>
    /// НОВЕ: Ініціалізує Image для ефектів.
    /// </summary>
    private void InitializeFlashImage(Image flashImage)
    {
        if (flashImage != null)
        {
            Color color = flashImage.color;
            color.a = 0;
            flashImage.color = color;
            flashImage.gameObject.SetActive(false);
        }
    }

    /// <summary>
    /// Запускає тряску камери з кастомними параметрами.
    /// </summary>
    public void Shake(float duration, float magnitude)
    {
        if (magnitude <= 0) return; // Не трясемо, якщо сила 0
        if (shakeCoroutine != null) StopCoroutine(shakeCoroutine);
        shakeCoroutine = StartCoroutine(ShakeCoroutine(duration, magnitude));
    }

    /// <summary>
    /// Запускає тряску камери зі стандартними параметрами.
    /// </summary>
    public void Shake()
    {
        Shake(defaultShakeDuration, defaultShakeMagnitude);
    }

    /// <summary>
    /// Запускає червоний спалах на екрані при отриманні урону.
    /// </summary>
    public void FlashDamageEffect()
    {
        if (damageFlashImage == null) return;
        
        if (damageFlashCoroutine != null) StopCoroutine(damageFlashCoroutine);
        damageFlashCoroutine = StartCoroutine(FlashCoroutine(damageFlashImage, flashDuration, maxFlashAlpha));
    }

    /// <summary>
    /// ПОКРАЩЕНО: Запускає ефект лікування з пульсаціями.
    /// </summary>
    public void PlayHealEffect()
    {
        if (healFlashImage != null)
        {
            if (healFlashCoroutine != null) StopCoroutine(healFlashCoroutine);
            healFlashCoroutine = StartCoroutine(HealEffectCoroutine());
        }
        
        // Додаємо легку тряску при лікуванні
        if (healShakeMagnitude > 0)
        {
            Shake(healEffectDuration * 0.3f, healShakeMagnitude);
        }
    }
    
    /// <summary>
    /// НОВЕ: Запускає або зупиняє попередження про низьке здоров'я.
    /// </summary>
    public void SetLowHealthWarning(bool active)
    {
        if (lowHealthWarningImage == null) return;
        
        if (active && !isLowHealthWarningActive)
        {
            isLowHealthWarningActive = true;
            if (lowHealthWarningCoroutine != null) StopCoroutine(lowHealthWarningCoroutine);
            lowHealthWarningCoroutine = StartCoroutine(LowHealthWarningCoroutine());
        }
        else if (!active && isLowHealthWarningActive)
        {
            isLowHealthWarningActive = false;
            if (lowHealthWarningCoroutine != null) StopCoroutine(lowHealthWarningCoroutine);
            lowHealthWarningImage.gameObject.SetActive(false);
        }
    }
    
    /// <summary>
    /// НОВЕ: Оновлює попередження про низьке здоров'я на основі поточного відсотка здоров'я.
    /// </summary>
    public void UpdateLowHealthWarning(float healthPercentage)
    {
        bool shouldShowWarning = healthPercentage <= lowHealthThreshold;
        SetLowHealthWarning(shouldShowWarning);
    }

    /// <summary>
    /// НОВЕ: Спеціальна корутина для ефекту лікування з пульсаціями.
    /// </summary>
    private IEnumerator HealEffectCoroutine()
    {
        healFlashImage.gameObject.SetActive(true);
        Color healColor = healFlashImage.color;
        
        float pulseTime = healEffectDuration / (healPulseCount * 2); // Час на одну пульсацію
        
        for (int pulse = 0; pulse < healPulseCount; pulse++)
        {
            // Фаза появи
            float elapsed = 0f;
            while (elapsed < pulseTime)
            {
                elapsed += Time.deltaTime;
                float alpha = Mathf.Lerp(0, maxHealAlpha, elapsed / pulseTime);
                healColor.a = alpha;
                healFlashImage.color = healColor;
                yield return null;
            }
            
            // Фаза зникнення
            elapsed = 0f;
            while (elapsed < pulseTime)
            {
                elapsed += Time.deltaTime;
                float alpha = Mathf.Lerp(maxHealAlpha, 0, elapsed / pulseTime);
                healColor.a = alpha;
                healFlashImage.color = healColor;
                yield return null;
            }
            
            // Коротка пауза між пульсаціями
            if (pulse < healPulseCount - 1)
            {
                yield return new WaitForSeconds(0.05f);
            }
        }
        
        healFlashImage.gameObject.SetActive(false);
    }
    
    /// <summary>
    /// НОВЕ: Корутина для постійного попередження про низьке здоров'я.
    /// </summary>
    private IEnumerator LowHealthWarningCoroutine()
    {
        lowHealthWarningImage.gameObject.SetActive(true);
        Color warningColor = lowHealthWarningImage.color;
        
        while (isLowHealthWarningActive)
        {
            // Пульсація попередження
            float time = Time.time * lowHealthPulseSpeed;
            float alpha = (Mathf.Sin(time) + 1f) * 0.5f * maxLowHealthAlpha;
            warningColor.a = alpha;
            lowHealthWarningImage.color = warningColor;
            
            yield return null;
        }
    }

    private IEnumerator ShakeCoroutine(float duration, float magnitude)
    {
        float elapsed = 0.0f;

        while (elapsed < duration)
        {
            float x = Random.Range(-1f, 1f) * magnitude;
            float y = Random.Range(-1f, 1f) * magnitude;
            
            transform.localPosition = new Vector3(originalCameraPosition.x + x, originalCameraPosition.y + y, originalCameraPosition.z);
            
            elapsed += Time.deltaTime;
            
            yield return null;
        }
        
        transform.localPosition = originalCameraPosition;
    }
    
    /// <summary>
    /// Універсальна корутина для спалаху на екрані.
    /// </summary>
    private IEnumerator FlashCoroutine(Image flashImage, float duration, float maxAlpha)
    {
        flashImage.gameObject.SetActive(true);
        float elapsed = 0.0f;
        Color flashColor = flashImage.color;
        
        // Фаза появи спалаху
        while (elapsed < duration / 2)
        {
            elapsed += Time.deltaTime;
            flashColor.a = Mathf.Lerp(0, maxAlpha, elapsed / (duration / 2));
            flashImage.color = flashColor;
            yield return null;
        }

        // Фаза зникнення спалаху
        elapsed = 0.0f;
        while (elapsed < duration / 2)
        {
            elapsed += Time.deltaTime;
            flashColor.a = Mathf.Lerp(maxAlpha, 0, elapsed / (duration / 2));
            flashImage.color = flashColor;
            yield return null;
        }

        flashImage.gameObject.SetActive(false);
    }
    
    /// <summary>
    /// НОВІ ПУБЛІЧНІ МЕТОДИ для зручності використання
    /// </summary>
    
    /// <summary>
    /// Запускає комбінований ефект урону (спалах + тряска).
    /// </summary>
    public void PlayDamageEffect(float customShakeMagnitude = 0f)
    {
        FlashDamageEffect();
        if (customShakeMagnitude > 0)
        {
            Shake(defaultShakeDuration, customShakeMagnitude);
        }
        else
        {
            Shake();
        }
    }
    
    /// <summary>
    /// Зупиняє всі активні ефекти.
    /// </summary>
    public void StopAllEffects()
    {
        if (shakeCoroutine != null) { StopCoroutine(shakeCoroutine); transform.localPosition = originalCameraPosition; }
        if (damageFlashCoroutine != null) { StopCoroutine(damageFlashCoroutine); if (damageFlashImage != null) damageFlashImage.gameObject.SetActive(false); }
        if (healFlashCoroutine != null) { StopCoroutine(healFlashCoroutine); if (healFlashImage != null) healFlashImage.gameObject.SetActive(false); }
        SetLowHealthWarning(false);
    }
    
    /// <summary>
    /// Повертає, чи активне попередження про низьке здоров'я.
    /// </summary>
    public bool IsLowHealthWarningActive()
    {
        return isLowHealthWarningActive;
    }
}
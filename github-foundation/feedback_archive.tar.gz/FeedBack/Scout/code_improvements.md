# Конкретні покращення коду для інді-шутера

## 🔧 Виправлення критичних проблем

### 1. Виправлення системи віддачі

#### Додати в MouseLook.cs:
```csharp
// Додати в кінець класу MouseLook
/// <summary>
/// Застосовує віддачу до поточних кутів камери та тіла гравця.
/// </summary>
public void ApplyRecoil(Vector3 recoilAmount)
{
    // Застосовуємо віддачу до камери (вертикальна)
    currentCameraRotationX += recoilAmount.x;
    currentCameraRotationX = Mathf.Clamp(currentCameraRotationX, minimumX, maximumX);
    
    // Застосовуємо віддачу до тіла (горизонтальна)
    currentBodyRotationY += recoilAmount.y;
    
    // Можна додати Z-віддачу для нахилу (roll)
    // Для цього потрібно буде розширити систему
}
```

#### Оновити UpdateRecoil в WeaponController.cs:
```csharp
/// <summary>
/// Оновлює стан віддачі та застосовує її до MouseLook.
/// </summary>
void UpdateRecoil()
{
    if (mouseLook == null) return;

    Vector3 previousRecoil = currentRecoilRotation;
    currentRecoilRotation = Vector3.Lerp(currentRecoilRotation, targetRecoilRotation, Time.deltaTime * recoilSnappiness);
    targetRecoilRotation = Vector3.Lerp(targetRecoilRotation, Vector3.zero, Time.deltaTime * recoilReturnSpeed);
    
    // НОВИЙ КОД: Застосовуємо різницю віддачі до MouseLook
    Vector3 recoilDelta = currentRecoilRotation - previousRecoil;
    if (recoilDelta.magnitude > 0.001f) // Уникаємо мікроскопічних змін
    {
        mouseLook.ApplyRecoil(recoilDelta);
    }
}
```

### 2. Покращення ефектів лікування

#### Оновити Heal в PlayerHealth.cs:
```csharp
/// <summary>
/// Відновлення здоров'я гравця з візуальними ефектами.
/// </summary>
public void Heal(float healAmount)
{
    if (isDead) return;

    float previousHealth = currentHealth;
    currentHealth += healAmount;
    currentHealth = Mathf.Min(maxHealth, currentHealth);

    // НОВИЙ КОД: Візуальні ефекти лікування
    if (cameraEffects != null && currentHealth > previousHealth)
    {
        cameraEffects.PlayHealEffect();
    }

    Debug.Log($"Player healed {healAmount} health. Current Health: {currentHealth}");
}
```

### 3. Оптимізація PlayerInteraction

#### Оновити CheckForInteractable:
```csharp
public class PlayerInteraction : MonoBehaviour
{
    // Додати нові поля
    [Header("Performance Settings")]
    [Tooltip("Інтервал між перевірками взаємодії (в секундах).")]
    public float raycastInterval = 0.1f;
    
    private float lastRaycastTime;
    private float lastInteractionTime; // Для уникнення спаму взаємодії

    void Update()
    {
        // Оптимізована перевірка
        if (Time.time - lastRaycastTime >= raycastInterval)
        {
            CheckForInteractable();
            lastRaycastTime = Time.time;
        }
        
        HandleInteractionInput();
    }

    /// <summary>
    /// Оновлена обробка вводу з захистом від спаму.
    /// </summary>
    private void HandleInteractionInput()
    {
        if (currentInteractable != null && 
            Input.GetKeyDown(interactionKey) && 
            Time.time - lastInteractionTime > 0.2f) // Захист від спаму
        {
            bool success = currentInteractable.Interact(this.gameObject);
            lastInteractionTime = Time.time;
            
            if (success)
            {
                // Можна додати звук успішної взаємодії
                Debug.Log($"Successfully interacted with {currentInteractable.name}");
            }
        }
    }
}
```

## 🚀 Нові системи для покращення

### 1. Event System для зменшення coupling

#### Новий файл: GameEvents.cs
```csharp
using UnityEngine;
using System;

/// <summary>
/// Централізована система подій для всієї гри.
/// Зменшує coupling між компонентами.
/// </summary>
public static class GameEvents
{
    // Події зброї
    public static event Action<int> OnAmmoChanged;
    public static event Action<int> OnWeaponSwitched;
    public static event Action OnWeaponReloadStarted;
    public static event Action OnWeaponReloadCompleted;
    
    // Події здоров'я
    public static event Action<float> OnHealthChanged;
    public static event Action OnPlayerDied;
    public static event Action OnPlayerRespawned;
    
    // Події взаємодії
    public static event Action<GameObject> OnInteractionStarted;
    public static event Action<GameObject> OnInteractionCompleted;
    
    // Методи для виклику подій
    public static void AmmoChanged(int newAmount) => OnAmmoChanged?.Invoke(newAmount);
    public static void WeaponSwitched(int weaponIndex) => OnWeaponSwitched?.Invoke(weaponIndex);
    public static void WeaponReloadStarted() => OnWeaponReloadStarted?.Invoke();
    public static void WeaponReloadCompleted() => OnWeaponReloadCompleted?.Invoke();
    
    public static void HealthChanged(float newHealth) => OnHealthChanged?.Invoke(newHealth);
    public static void PlayerDied() => OnPlayerDied?.Invoke();
    public static void PlayerRespawned() => OnPlayerRespawned?.Invoke();
    
    public static void InteractionStarted(GameObject target) => OnInteractionStarted?.Invoke(target);
    public static void InteractionCompleted(GameObject target) => OnInteractionCompleted?.Invoke(target);
}
```

#### Інтеграція в WeaponController:
```csharp
void Shoot()
{
    nextFireTime = Time.time + 1f / fireRate;
    currentAmmo--;
    
    // ДОДАТИ: Повідомити про зміну патронів
    GameEvents.AmmoChanged(currentAmmo);
    
    // ... решта коду стрільби
}

IEnumerator ReloadCoroutine()
{
    GameEvents.WeaponReloadStarted(); // ДОДАТИ
    
    yield return new WaitForSeconds(reloadTime);

    currentAmmo = magazineSize;
    isReloading = false;
    
    GameEvents.WeaponReloadCompleted(); // ДОДАТИ
    GameEvents.AmmoChanged(currentAmmo); // ДОДАТИ
    
    Debug.Log("Reloaded!");
}
```

### 2. Pool System для куль

#### Новий файл: BulletPool.cs
```csharp
using UnityEngine;
using System.Collections.Generic;

/// <summary>
/// Система пулу об'єктів для куль.
/// Зменшує навантаження на garbage collector.
/// </summary>
public class BulletPool : MonoBehaviour
{
    [Header("Pool Settings")]
    public GameObject bulletPrefab;
    public int poolSize = 100;
    public Transform poolParent; // Для організації в ієрархії
    
    private Queue<GameObject> availableBullets = new Queue<GameObject>();
    private List<GameObject> allBullets = new List<GameObject>();
    
    public static BulletPool Instance { get; private set; }
    
    void Awake()
    {
        if (Instance == null)
        {
            Instance = this;
            InitializePool();
        }
        else
        {
            Destroy(gameObject);
        }
    }
    
    void InitializePool()
    {
        if (poolParent == null)
        {
            GameObject poolContainer = new GameObject("Bullet Pool");
            poolParent = poolContainer.transform;
        }
        
        for (int i = 0; i < poolSize; i++)
        {
            GameObject bullet = Instantiate(bulletPrefab, poolParent);
            bullet.SetActive(false);
            availableBullets.Enqueue(bullet);
            allBullets.Add(bullet);
            
            // Модифікуємо Bullet скрипт для роботи з пулом
            Bullet bulletScript = bullet.GetComponent<Bullet>();
            if (bulletScript != null)
            {
                bulletScript.SetPool(this);
            }
        }
    }
    
    public GameObject GetBullet()
    {
        if (availableBullets.Count > 0)
        {
            GameObject bullet = availableBullets.Dequeue();
            bullet.SetActive(true);
            return bullet;
        }
        
        // Якщо пул порожній, створюємо нову кулю
        Debug.LogWarning("Bullet pool is empty, creating new bullet");
        GameObject newBullet = Instantiate(bulletPrefab);
        Bullet bulletScript = newBullet.GetComponent<Bullet>();
        if (bulletScript != null)
        {
            bulletScript.SetPool(this);
        }
        return newBullet;
    }
    
    public void ReturnBullet(GameObject bullet)
    {
        bullet.SetActive(false);
        bullet.transform.SetParent(poolParent);
        availableBullets.Enqueue(bullet);
    }
}
```

#### Оновлений Bullet.cs:
```csharp
using UnityEngine;

public class Bullet : MonoBehaviour
{
    [Tooltip("Час (у секундах) до самознищення кулі")]
    public float lifeTime = 3f;
    [Tooltip("Ефект, який з'являється при ударі кулі")]
    public GameObject hitEffectPrefab;
    
    private BulletPool bulletPool; // НОВЕ
    private float spawnTime; // НОВЕ
    
    void OnEnable() // Змінено з Start
    {
        spawnTime = Time.time;
    }
    
    void Update() // НОВЕ: Перевірка на час життя
    {
        if (Time.time - spawnTime > lifeTime)
        {
            ReturnToPool();
        }
    }
    
    /// <summary>
    /// Встановлює пул для цієї кулі (викликається з BulletPool).
    /// </summary>
    public void SetPool(BulletPool pool)
    {
        bulletPool = pool;
    }
    
    void OnCollisionEnter(Collision collision)
    {
        // Створення ефекту удару
        if (hitEffectPrefab != null)
        {
            GameObject hitEffect = Instantiate(hitEffectPrefab, 
                collision.contacts[0].point, 
                Quaternion.LookRotation(collision.contacts[0].normal));
            Destroy(hitEffect, 1f);
        }

        // Тут можна додати логіку нанесення шкоди
        
        ReturnToPool();
    }
    
    /// <summary>
    /// Повертає кулю в пул замість знищення.
    /// </summary>
    private void ReturnToPool()
    {
        if (bulletPool != null)
        {
            bulletPool.ReturnBullet(gameObject);
        }
        else
        {
            Destroy(gameObject); // Fallback якщо пул не встановлено
        }
    }
}
```

#### Оновлення WeaponController для використання пулу:
```csharp
void Shoot()
{
    // ... код до створення кулі

    GameObject bullet;
    if (BulletPool.Instance != null)
    {
        bullet = BulletPool.Instance.GetBullet();
        bullet.transform.position = bulletSpawnPoint.position;
        bullet.transform.rotation = bulletRotation;
    }
    else
    {
        bullet = Instantiate(bulletPrefab, bulletSpawnPoint.position, bulletRotation);
    }
    
    // ... решта коду
}
```

### 3. GameManager для централізованого керування

#### Новий файл: GameManager.cs
```csharp
using UnityEngine;

/// <summary>
/// Центральний менеджер гри для керування станами та глобальними системами.
/// </summary>
public class GameManager : MonoBehaviour
{
    public enum GameState { Menu, Playing, Paused, GameOver, Loading }
    
    [Header("Game State")]
    [SerializeField] private GameState currentState = GameState.Menu;
    
    [Header("UI References")]
    public GameObject pauseMenu;
    public GameObject gameOverMenu;
    public GameObject hudCanvas;
    
    public static GameManager Instance { get; private set; }
    public GameState CurrentState => currentState;
    
    // Події стану гри
    public static event System.Action<GameState> OnStateChanged;
    
    void Awake()
    {
        if (Instance == null)
        {
            Instance = this;
            DontDestroyOnLoad(gameObject);
            InitializeGame();
        }
        else
        {
            Destroy(gameObject);
        }
    }
    
    void Update()
    {
        HandleInput();
    }
    
    void InitializeGame()
    {
        // Підписка на події
        GameEvents.OnPlayerDied += () => ChangeState(GameState.GameOver);
        GameEvents.OnPlayerRespawned += () => ChangeState(GameState.Playing);
        
        // Встановлення початкового стану
        ChangeState(GameState.Menu);
    }
    
    void HandleInput()
    {
        if (Input.GetKeyDown(KeyCode.Escape))
        {
            switch (currentState)
            {
                case GameState.Playing:
                    ChangeState(GameState.Paused);
                    break;
                case GameState.Paused:
                    ChangeState(GameState.Playing);
                    break;
            }
        }
    }
    
    public void ChangeState(GameState newState)
    {
        if (currentState == newState) return;
        
        GameState previousState = currentState;
        currentState = newState;
        
        ApplyStateChanges(previousState, newState);
        OnStateChanged?.Invoke(newState);
        
        Debug.Log($"Game state changed: {previousState} -> {newState}");
    }
    
    void ApplyStateChanges(GameState from, GameState to)
    {
        switch (to)
        {
            case GameState.Menu:
                Time.timeScale = 1f;
                SetCursorState(true);
                SetUIState(false, false, false);
                break;
                
            case GameState.Playing:
                Time.timeScale = 1f;
                SetCursorState(false);
                SetUIState(true, false, false);
                break;
                
            case GameState.Paused:
                Time.timeScale = 0f;
                SetCursorState(true);
                SetUIState(true, true, false);
                break;
                
            case GameState.GameOver:
                Time.timeScale = 0f;
                SetCursorState(true);
                SetUIState(false, false, true);
                break;
        }
    }
    
    void SetCursorState(bool visible)
    {
        Cursor.visible = visible;
        Cursor.lockState = visible ? CursorLockMode.None : CursorLockMode.Locked;
    }
    
    void SetUIState(bool hud, bool pause, bool gameOver)
    {
        if (hudCanvas != null) hudCanvas.SetActive(hud);
        if (pauseMenu != null) pauseMenu.SetActive(pause);
        if (gameOverMenu != null) gameOverMenu.SetActive(gameOver);
    }
    
    // Публічні методи для UI
    public void StartGame() => ChangeState(GameState.Playing);
    public void PauseGame() => ChangeState(GameState.Paused);
    public void ResumeGame() => ChangeState(GameState.Playing);
    public void RestartGame() => ChangeState(GameState.Loading); // Можна розширити
    public void QuitGame() => Application.Quit();
}
```

## 📝 Додаткові покращення

### 1. Система налаштувань
```csharp
[System.Serializable]
public class GameSettings
{
    [Range(0f, 1f)] public float masterVolume = 1f;
    [Range(0f, 1f)] public float sfxVolume = 1f;
    [Range(0f, 1f)] public float musicVolume = 1f;
    [Range(1f, 10f)] public float mouseSensitivity = 2f;
    public bool invertMouseY = false;
    public KeyCode interactionKey = KeyCode.E;
    public KeyCode sprintKey = KeyCode.LeftShift;
    
    public void Save()
    {
        string json = JsonUtility.ToJson(this);
        PlayerPrefs.SetString("GameSettings", json);
        PlayerPrefs.Save();
    }
    
    public static GameSettings Load()
    {
        string json = PlayerPrefs.GetString("GameSettings", "");
        if (string.IsNullOrEmpty(json))
            return new GameSettings();
        return JsonUtility.FromJson<GameSettings>(json);
    }
}
```

### 2. Система звуків
```csharp
public class AudioManager : MonoBehaviour
{
    [System.Serializable]
    public class Sound
    {
        public string name;
        public AudioClip clip;
        [Range(0f, 1f)] public float volume = 1f;
        [Range(0.1f, 3f)] public float pitch = 1f;
        public bool loop = false;
        [HideInInspector] public AudioSource source;
    }
    
    public Sound[] sounds;
    public static AudioManager Instance;
    
    void Awake()
    {
        if (Instance == null)
        {
            Instance = this;
            DontDestroyOnLoad(gameObject);
            InitializeSounds();
        }
        else
        {
            Destroy(gameObject);
        }
    }
    
    void InitializeSounds()
    {
        foreach (Sound s in sounds)
        {
            s.source = gameObject.AddComponent<AudioSource>();
            s.source.clip = s.clip;
            s.source.volume = s.volume;
            s.source.pitch = s.pitch;
            s.source.loop = s.loop;
        }
    }
    
    public void Play(string name)
    {
        Sound s = System.Array.Find(sounds, sound => sound.name == name);
        if (s == null)
        {
            Debug.LogWarning($"Sound {name} not found!");
            return;
        }
        s.source.Play();
    }
    
    public void Stop(string name)
    {
        Sound s = System.Array.Find(sounds, sound => sound.name == name);
        if (s == null) return;
        s.source.Stop();
    }
}
```

Ці покращення значно підвищать якість та продуктивність вашого проекту!
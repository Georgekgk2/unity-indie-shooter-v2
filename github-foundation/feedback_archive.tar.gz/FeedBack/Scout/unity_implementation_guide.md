# 🛠️ Покроковий гайд впровадження в Unity

## 📋 Передумови

**Перед початком переконайтеся:**
- ✅ Unity проект відкрито
- ✅ Всі файли покращень завантажено
- ✅ Проект компілюється без помилок
- ✅ Є backup поточної версії

## 🎯 Етап 0: Підготовка (5 хвилин)

### 1. Створення backup
```bash
# Створіть копію папки Assets
Assets/ → Assets_Backup_[дата]/
```

### 2. Підготовка файлів покращень
1. Створіть папку `Scripts/Improvements/` в Assets
2. Скопіюйте всі improved_ файли туди
3. Скопіюйте всі нові системи (.cs файли)

### 3. Перевірка поточного стану
- [ ] Відкрийте сцену з гравцем
- [ ] Знайдіть GameObject з MouseLook компонентом
- [ ] Знайдіть GameObject з WeaponController компонентом
- [ ] Знайдіть GameObject з PlayerInteraction компонентом
- [ ] Знайдіть GameObject з CameraEffects компонентом

---

## 🔴 ФАЗА 1: Критичні виправлення (30 хвилин)

### Крок 1.1: Виправлення віддачі MouseLook (10 хв)

#### Підготовка:
1. **Знайдіть GameObject з MouseLook компонентом**
2. **Запишіть поточні налаштування:**
   - horizontalSensitivity: ____
   - verticalSensitivity: ____
   - playerBody: ____
   - playerCamera: ____

#### Заміна скрипту:
1. **Збережіть налаштування** - сфотографуйте Inspector
2. **Видаліть старий MouseLook компонент**
3. **Додайте `improved_MouseLook.cs`:**
   - Component → Scripts → improved_MouseLook
4. **Відновіть налаштування** з фото
5. **Перевірте посилання:** playerBody та playerCamera мають бути призначені

#### ✅ Перевірка:
```csharp
// У консолі Unity має з'явитися при старті гри:
// "MouseLook: ініціалізовано успішно"
```

### Крок 1.2: Виправлення віддачі WeaponController (10 хв)

#### Підготовка:
1. **Знайдіть GameObject з WeaponController компонентом**
2. **Запишіть ВСІ налаштування** (багато полів!)

#### Заміна скрипту:
1. **Збережіть налаштування** - сфотографуйте Inspector
2. **Видаліть старий WeaponController компонент**
3. **Додайте `improved_WeaponController.cs`**
4. **Відновіть ВСІ налаштування** з фото
5. **Перевірте посилання:** bulletPrefab, bulletSpawnPoint, muzzleFlash тощо

#### ✅ Перевірка:
- [ ] Компонент завантажився без помилок
- [ ] Всі поля заповнені
- [ ] mouseLook посилання автоматично знайдено

### Крок 1.3: Оптимізація PlayerInteraction (5 хв)

#### Заміна скрипту:
1. **Збережіть налаштування PlayerInteraction**
2. **Замініть на `improved_PlayerInteraction.cs`**
3. **Відновіть налаштування**
4. **Налаштуйте нові параметри:**
   - Raycast Interval: `0.1` (секунди)
   - Interaction Cooldown: `0.3` (секунди)

#### ✅ Перевірка:
```csharp
// У консолі при взаємодії:
// "Interacted with: [назва об'єкта]"
```

### Крок 1.4: Покращення CameraEffects (5 хв)

#### Заміна скрипту:
1. **Збережіть налаштування CameraEffects**
2. **Замініть на `improved_CameraEffects.cs`**
3. **Відновіть налаштування**

#### Додання UI елементів для нових ефектів:
1. **Canvas → UI → Image** (для heal ефекту)
   - Name: `HealFlashImage`
   - Color: Light Green (255,255,255,0) - прозорий
   - Anchors: Stretch to full screen
2. **Canvas → UI → Image** (для low health попередження)
   - Name: `LowHealthWarningImage`  
   - Color: Dark Red (255,0,0,0) - прозорий
   - Anchors: Stretch to full screen
3. **Призначте ці UI елементи** в CameraEffects компоненті

#### ✅ Перевірка ФАЗИ 1:
**Тест в Play Mode:**
- [ ] Стрільба: камера відхиляється (віддача працює!)
- [ ] Взаємодія: працює плавно без зависань
- [ ] Ефекти: урон показує червоний спалах
- [ ] Консоль: немає помилок

---

## 🟡 ФАЗА 2: Нові системи (1 година)

### Крок 2.1: Додавання Event System (10 хв)

#### Установка:
1. **Додайте `GameEvents.cs`** в папку Scripts/
2. **Компіляція:** чекайте завершення компіляції Unity
3. **Перевірка:** немає помилок у консолі

#### ✅ Перевірка:
```csharp
// Events доступні статично:
// GameEvents.OnPlayerHealthChanged
```

### Крок 2.2: Створення GameManager (15 хв)

#### Створення об'єкта:
1. **Create → Empty GameObject**
2. **Name:** "GameManager"
3. **Add Component:** `GameManager.cs`

#### Налаштування GameManager:
```
Initial Game State: Playing
Can Pause: true
Pause Key: Escape
Player Prefab: [ваш префаб гравця]
Default Spawn Point: [Transform точки спавну]
Max Lives: 3
Main Menu Scene Name: "MainMenu"
Game Over Delay: 2
Enable Debug Logging: true
```

#### ✅ Перевірка:
- [ ] GameObject створено
- [ ] Компонент доданий
- [ ] Налаштування збережені
- [ ] У консолі: "GameManager: Гра ініціалізована"

### Крок 2.3: Створення BulletPool системи (20 хв)

#### A. Створення BulletPool:
1. **Create → Empty GameObject**
2. **Name:** "BulletPool"  
3. **Add Component:** `BulletPool.cs`

#### B. Налаштування BulletPool:
```
Bullet Prefab: [ваш префаб кулі]
Initial Pool Size: 50
Max Pool Size: 100
Auto Expand: true
Use Auto Return: true
Bullet Lifetime: 10
Enable Debug Logging: true
```

#### C. Модифікація префабу кулі:
1. **Відкрийте префаб кулі**
2. **Add Component:** `BulletPoolItem.cs`
3. **Налаштуйте BulletPoolItem:**
   ```
   Use Auto Return: true
   Custom Lifetime: -1 (використовувати з пулу)
   ```
4. **Збережіть префаб**

#### D. Інтеграція з WeaponController:
**У improved_WeaponController.cs знайдіть метод Shoot() рядок ~300:**

```csharp
// СТАРИЙ КОД (закоментуйте):
// GameObject bullet = Instantiate(bulletPrefab, bulletSpawnPoint.position, bulletRotation);

// НОВИЙ КОД (додайте):
GameObject bullet = BulletPool.Instance.GetBullet();
if (bullet != null)
{
    bullet.transform.position = bulletSpawnPoint.position;
    bullet.transform.rotation = bulletRotation;
}
else
{
    Debug.LogWarning("BulletPool: Куля недоступна!");
    return;
}
```

#### ✅ Перевірка BulletPool:
**Тест в Play Mode:**
- [ ] Стрільба: кулі створюються
- [ ] Консоль: "BulletPool: Ініціалізовано з 50 кулями"
- [ ] Кулі зникають через 10 секунд
- [ ] Статистика: F1 показує інформацію про пул

### Крок 2.4: Створення UpdateManager (15 хв)

#### Створення системи:
1. **Create → Empty GameObject**
2. **Name:** "UpdateManager"
3. **Add Component:** `UpdateManager.cs`

#### Налаштування:
```
Base Update Rate: 60
Slow Update Rate: 10  
Very Slow Update Rate: 1
```

#### Приклад використання (опціонально):
Якщо хочете перевести якийсь скрипт на керовані оновлення:

```csharp
// Замість: public class MyScript : MonoBehaviour
public class MyScript : ManagedBehaviour
{
    protected override void Start()
    {
        base.Start();
        useSlowUpdate = true; // Використовувати повільні оновлення
    }

    public override void OnSlowUpdate(float deltaTime)
    {
        // Код що не потребує частих оновлень
    }
}
```

#### ✅ Перевірка UpdateManager:
- [ ] GameObject створено
- [ ] Компонент працює
- [ ] У консолі немає помилок

---

## 🔵 ФАЗА 3: Інтеграція та тестування (30 хвилин)

### Крок 3.1: Інтеграція Event System (15 хв)

#### Підключення PlayerHealth до Events:
**Знайдіть PlayerHealth скрипт і додайте в метод TakeDamage:**

```csharp
// Після зміни здоров'я додайте:
float healthPercentage = (float)currentHealth / maxHealth;
GameEvents.SafeInvoke(GameEvents.OnPlayerHealthChanged, currentHealth, maxHealth, healthPercentage);

// При смерті:
if (currentHealth <= 0)
{
    GameEvents.SafeInvoke(GameEvents.OnPlayerDied);
}
```

#### Підключення CameraEffects до Events:
**У CameraEffects додайте в Start():**

```csharp
void Start()
{
    // Підписуємося на події
    GameEvents.OnPlayerDamaged += (damage, health, source) => FlashDamageEffect();
    GameEvents.OnPlayerHealed += (heal, health) => PlayHealEffect();
    GameEvents.OnPlayerHealthChanged += (current, max, percentage) => UpdateLowHealthWarning(percentage);
}

void OnDestroy()
{
    // Відписуємося
    GameEvents.OnPlayerDamaged -= (damage, health, source) => FlashDamageEffect();
    GameEvents.OnPlayerHealed -= (heal, health) => PlayHealEffect();
    GameEvents.OnPlayerHealthChanged -= (current, max, percentage) => UpdateLowHealthWarning(percentage);
}
```

### Крок 3.2: Фінальне тестування (15 хв)

#### Комплексний тест:
1. **Запустіть Play Mode**
2. **Перевірте віддачу:** стріляйте - камера має відхилятися
3. **Перевірте взаємодії:** підійдіть до двері/предмету
4. **Перевірте пул куль:** стріляйте швидко 10+ разів
5. **Перевірте ефекти:** отримайте урон та лікування
6. **Перевірте паузу:** натисніть Escape

#### Перевірка консолі:
```
✅ Очікувані повідомлення:
- "GameManager: Гра ініціалізована"
- "BulletPool: Ініціалізовано з 50 кулями"  
- "MouseLook: ініціалізовано успішно"
- При взаємодії: "Interacted with: [об'єкт]"

❌ НЕ повинно бути:
- NullReferenceException
- MissingComponentException
- Compilation errors
```

#### Performance тест:
1. **Відкрийте Profiler** (Window → Analysis → Profiler)
2. **Стріляйте 20+ куль швидко**
3. **Перевірте:**
   - GC Alloc має бути мінімальним
   - FPS стабільний
   - Немає спайків у Memory

---

## 🎯 Фінальна перевірка

### ✅ Checklist готовності:

#### Віддача зброї:
- [ ] Камера відхиляється при стрільбі
- [ ] Віддача різна для ADS та hip fire
- [ ] Віддача плавно повертається

#### Взаємодії:
- [ ] Підказки з'являються плавно
- [ ] Немає зависань при наведенні
- [ ] Кулдаун працює (не можна спамити E)

#### Візуальні ефекти:
- [ ] Червоний спалах при уроні
- [ ] Зелений ефект при лікуванні  
- [ ] Попередження при низькому здоров'ї

#### Системи:
- [ ] GameManager управляє паузою
- [ ] BulletPool створює/повертає кулі
- [ ] Events підключено (урон → ефекти)
- [ ] Консоль без критичних помилок

#### Продуктивність:
- [ ] FPS стабільний
- [ ] Профайлер показує мінімальні GC спайки
- [ ] Плавна робота взаємодій

---

## 🚨 Вирішення проблем

### Віддача не працює:
1. Перевірте посилання mouseLook у WeaponController
2. Перевірте чи додано метод ApplyRecoil у MouseLook
3. Перевірте recoilX > 0 у налаштуваннях

### BulletPool помилки:
1. Перевірте чи призначено bulletPrefab
2. Перевірте чи доданий BulletPoolItem до префабу кулі
3. Перевірте чи BulletPool.Instance не null

### UI ефекти не працюють:
1. Перевірте чи створені UI Image елементи
2. Перевірте чи призначені в CameraEffects
3. Перевірте чи підписані на события

### Проблеми компіляції:
1. Перевірте всі using директиви
2. Видаліть старі скрипти перед додаванням нових
3. Restart Unity Editor

---

## 🎉 Готово!

Після успішного впровадження ваш проект матиме:
- ✅ **Реалістичну віддачу зброї**
- ✅ **Оптимізовані взаємодії** 
- ✅ **Професійні візуальні ефекти**
- ✅ **Покращену продуктивність на 20-50%**
- ✅ **Модульну архітектуру** для розширення

**Проект готовий до релізу!** 🚀

---

*При виникненні проблем - перевірте консоль Unity та переконайтеся, що всі кроки виконані у правильному порядку.*
// HealthSystem.cs - Універсальна система здоров'я
using UnityEngine;
using UnityEngine.Events;

public class HealthSystem : MonoBehaviour
{
    [Header("Health Settings")]
    [SerializeField] private float maxHealth = 100f;
    [SerializeField] private float currentHealth;
    
    [Header("Events")]
    public UnityEvent<float> OnHealthChanged;
    public UnityEvent<float> OnDamageTaken;
    public UnityEvent<float> OnHealed;
    public UnityEvent OnDeath;
    public UnityEvent OnRespawn;
    
    // C# події для інших скриптів
    public static event System.Action<GameObject, float> OnAnyDamageTaken;
    public static event System.Action<GameObject> OnAnyDeath;
    
    // Властивості
    public float CurrentHealth => currentHealth;
    public float MaxHealth => maxHealth;
    public float HealthPercentage => currentHealth / maxHealth;
    public bool IsDead { get; private set; }
    
    void Awake()
    {
        currentHealth = maxHealth;
    }
    
    public virtual void TakeDamage(float amount, GameObject damageSource = null)
    {
        if (IsDead || amount <= 0) return;
        
        float previousHealth = currentHealth;
        currentHealth = Mathf.Max(0, currentHealth - amount);
        
        // Викликаємо події
        OnHealthChanged?.Invoke(currentHealth);
        OnDamageTaken?.Invoke(amount);
        OnAnyDamageTaken?.Invoke(gameObject, amount);
        
        if (currentHealth <= 0 && !IsDead)
        {
            Die();
        }
    }
    
    public virtual void Heal(float amount)
    {
        if (IsDead || amount <= 0) return;
        
        float previousHealth = currentHealth;
        currentHealth = Mathf.Min(maxHealth, currentHealth + amount);
        
        if (currentHealth > previousHealth)
        {
            OnHealthChanged?.Invoke(currentHealth);
            OnHealed?.Invoke(amount);
        }
    }
    
    protected virtual void Die()
    {
        IsDead = true;
        OnDeath?.Invoke();
        OnAnyDeath?.Invoke(gameObject);
    }
    
    public virtual void Respawn(float healthAmount = -1)
    {
        IsDead = false;
        currentHealth = healthAmount > 0 ? healthAmount : maxHealth;
        OnHealthChanged?.Invoke(currentHealth);
        OnRespawn?.Invoke();
    }
}

// PlayerHealth.cs - Спрощений варіант, що наслідує HealthSystem
public class PlayerHealth : HealthSystem
{
    [Header("Player Specific")]
    [SerializeField] private float invulnerabilityTime = 0.5f;
    [SerializeField] private float respawnDelay = 3f;
    
    private bool isInvulnerable;
    private PlayerController playerController;
    
    void Start()
    {
        playerController = GetComponent<PlayerController>();
        
        // Підписуємося на події
        OnDeath.AddListener(HandlePlayerDeath);
        OnRespawn.AddListener(HandlePlayerRespawn);
    }
    
    public override void TakeDamage(float amount, GameObject damageSource = null)
    {
        if (isInvulnerable) return;
        
        base.TakeDamage(amount, damageSource);
        
        if (!IsDead)
        {
            StartCoroutine(InvulnerabilityCoroutine());
        }
    }
    
    private void HandlePlayerDeath()
    {
        playerController.SetControlsEnabled(false);
        StartCoroutine(RespawnCoroutine());
    }
    
    private void HandlePlayerRespawn()
    {
        playerController.SetControlsEnabled(true);
    }
    
    private System.Collections.IEnumerator InvulnerabilityCoroutine()
    {
        isInvulnerable = true;
        yield return new WaitForSeconds(invulnerabilityTime);
        isInvulnerable = false;
    }
    
    private System.Collections.IEnumerator RespawnCoroutine()
    {
        yield return new WaitForSeconds(respawnDelay);
        Respawn();
    }
}
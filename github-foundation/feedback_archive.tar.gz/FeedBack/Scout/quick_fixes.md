# Швидкі виправлення (Quick Fixes)

## ⚡ Виправлення за 5 хвилин

### 1. Виправлення віддачі (КРИТИЧНО)

#### У MouseLook.cs додати наприкінці класу:
```csharp
/// <summary>
/// Застосовує віддачу до поточних кутів камери.
/// </summary>
public void ApplyRecoil(Vector3 recoilAmount)
{
    currentCameraRotationX += recoilAmount.x;
    currentCameraRotationX = Mathf.Clamp(currentCameraRotationX, minimumX, maximumX);
    currentBodyRotationY += recoilAmount.y;
}
```

#### У WeaponController.cs замінити метод UpdateRecoil:
```csharp
void UpdateRecoil()
{
    if (mouseLook == null) return;

    Vector3 previousRecoil = currentRecoilRotation;
    currentRecoilRotation = Vector3.Lerp(currentRecoilRotation, targetRecoilRotation, Time.deltaTime * recoilSnappiness);
    targetRecoilRotation = Vector3.Lerp(targetRecoilRotation, Vector3.zero, Time.deltaTime * recoilReturnSpeed);
    
    // НОВИЙ КОД: Застосування віддачі
    Vector3 recoilDelta = currentRecoilRotation - previousRecoil;
    if (recoilDelta.magnitude > 0.001f)
    {
        mouseLook.ApplyRecoil(recoilDelta);
    }
}
```

### 2. Додавання ефектів лікування

#### У PlayerHealth.cs в методі Heal додати після рядка 111:
```csharp
// Після: currentHealth = Mathf.Min(maxHealth, currentHealth);
// ДОДАТИ:
if (cameraEffects != null && healAmount > 0)
{
    cameraEffects.PlayHealEffect();
}
```

### 3. Захист від спаму взаємодії

#### У PlayerInteraction.cs додати поле:
```csharp
private float lastInteractionTime;
```

#### У методі HandleInteractionInput замінити умову:
```csharp
// ЗАМІНИТИ:
if (currentInteractable != null && Input.GetKeyDown(interactionKey))

// НА:
if (currentInteractable != null && Input.GetKeyDown(interactionKey) && Time.time - lastInteractionTime > 0.2f)
{
    currentInteractable.Interact(this.gameObject);
    lastInteractionTime = Time.time; // ДОДАТИ ЦЕЙ РЯДОК
}
```

## ⚡ Виправлення за 10 хвилин

### 4. Оптимізація PlayerInteraction

#### Додати поля в PlayerInteraction.cs:
```csharp
[Header("Performance")]
public float raycastInterval = 0.1f;
private float lastRaycastTime;
```

#### Замінити Update метод:
```csharp
void Update()
{
    // Оптимізована перевірка
    if (Time.time - lastRaycastTime >= raycastInterval)
    {
        CheckForInteractable();
        lastRaycastTime = Time.time;
    }
    
    HandleInteractionInput();
}
```

### 5. Покращення системи патронів

#### У WeaponController.cs в методі Shoot після рядка currentAmmo--:
```csharp
// Після: currentAmmo--;
// ДОДАТИ:
if (currentAmmo <= 0)
{
    // Автоматична перезарядка при закінченні патронів
    Invoke(nameof(Reload), 0.1f);
}
```

### 6. Налаштування чутливості миші

#### У MouseLook.cs додати метод:
```csharp
/// <summary>
/// Динамічна зміна чутливості миші.
/// </summary>
public void SetSensitivity(float horizontal, float vertical)
{
    horizontalSensitivity = horizontal;
    verticalSensitivity = vertical;
}

/// <summary>
/// Множник чутливості (для налаштувань).
/// </summary>
public void SetSensitivityMultiplier(float multiplier)
{
    horizontalSensitivity *= multiplier;
    verticalSensitivity *= multiplier;
}
```

## ⚡ Виправлення за 15 хвилин

### 7. Система звукових ефектів

#### Створити простий AudioManager (новий файл):
```csharp
using UnityEngine;

public class SimpleAudioManager : MonoBehaviour
{
    public static SimpleAudioManager Instance;
    
    [Header("Audio Sources")]
    public AudioSource sfxSource;
    public AudioSource musicSource;
    
    void Awake()
    {
        if (Instance == null)
        {
            Instance = this;
            DontDestroyOnLoad(gameObject);
        }
        else
        {
            Destroy(gameObject);
        }
    }
    
    public void PlaySFX(AudioClip clip, float volume = 1f)
    {
        if (sfxSource != null && clip != null)
        {
            sfxSource.PlayOneShot(clip, volume);
        }
    }
    
    public void PlayMusic(AudioClip clip, bool loop = true)
    {
        if (musicSource != null && clip != null)
        {
            musicSource.clip = clip;
            musicSource.loop = loop;
            musicSource.Play();
        }
    }
}
```

### 8. Додавання перевірок на null

#### У WeaponController.cs в методі Awake додати:
```csharp
// Після існуючих перевірок додати:
if (bulletSpawnPoint == null)
{
    Debug.LogError($"WeaponController на {gameObject.name}: bulletSpawnPoint не призначено!", this);
    enabled = false;
}

if (bulletPrefab == null)
{
    Debug.LogError($"WeaponController на {gameObject.name}: bulletPrefab не призначено!", this);
    enabled = false;
}
```

### 9. Покращення UI відгуку

#### У WeaponUIController.cs в методі UpdateWeaponUI додати перед кінцем:
```csharp
// Додати в кінець методу UpdateWeaponUI:
// Візуальний індикатор низьких патронів
if (activeWeaponController != null && ammoText != null)
{
    int currentAmmo = activeWeaponController.GetCurrentAmmo();
    int maxAmmo = activeWeaponController.GetMagazineSize();
    
    if (currentAmmo <= maxAmmo * 0.25f && !activeWeaponController.IsReloading())
    {
        // Мигання при низьких патронах
        float alpha = Mathf.PingPong(Time.time * 3f, 1f);
        Color color = ammoText.color;
        color.a = alpha;
        ammoText.color = color;
    }
}
```

## ⚡ Виправлення за 20 хвилин

### 10. Додавання системи пауз

#### Створити простий PauseManager:
```csharp
using UnityEngine;

public class SimplePauseManager : MonoBehaviour
{
    [Header("UI")]
    public GameObject pauseMenu;
    
    private bool isPaused = false;
    
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Escape))
        {
            TogglePause();
        }
    }
    
    public void TogglePause()
    {
        isPaused = !isPaused;
        
        if (isPaused)
        {
            Time.timeScale = 0f;
            Cursor.lockState = CursorLockMode.None;
            Cursor.visible = true;
            if (pauseMenu != null) pauseMenu.SetActive(true);
        }
        else
        {
            Time.timeScale = 1f;
            Cursor.lockState = CursorLockMode.Locked;
            Cursor.visible = false;
            if (pauseMenu != null) pauseMenu.SetActive(false);
        }
    }
    
    public void ResumeGame() => TogglePause();
    public void QuitGame() => Application.Quit();
}
```

### 11. Система налаштувань FOV

#### У MouseLook.cs додати:
```csharp
[Header("FOV Settings")]
public bool adjustFOVWithSensitivity = false;
public float baseFOV = 60f;

void Start()
{
    if (adjustFOVWithSensitivity && Camera.main != null)
    {
        float avgSensitivity = (horizontalSensitivity + verticalSensitivity) / 2f;
        Camera.main.fieldOfView = baseFOV + (avgSensitivity - 2f) * 5f;
    }
}
```

### 12. Статистика гравця

#### Додати в GameManager (якщо є) або створити новий скрипт:
```csharp
using UnityEngine;

public class PlayerStats : MonoBehaviour
{
    [Header("Statistics")]
    public int shotsFired = 0;
    public int shotsHit = 0;
    public int enemiesKilled = 0;
    public float timePlayed = 0f;
    
    void Update()
    {
        timePlayed += Time.deltaTime;
    }
    
    public void RecordShot() => shotsFired++;
    public void RecordHit() => shotsHit++;
    public void RecordKill() => enemiesKilled++;
    
    public float GetAccuracy()
    {
        return shotsFired > 0 ? (float)shotsHit / shotsFired * 100f : 0f;
    }
    
    void OnGUI()
    {
        if (Debug.isDebugBuild)
        {
            GUILayout.BeginArea(new Rect(10, 10, 200, 100));
            GUILayout.Label($"Shots: {shotsFired}");
            GUILayout.Label($"Hits: {shotsHit}");
            GUILayout.Label($"Accuracy: {GetAccuracy():F1}%");
            GUILayout.Label($"Time: {timePlayed:F1}s");
            GUILayout.EndArea();
        }
    }
}
```

## 🔥 Екстра: Миттєві покращення

### В Unity Inspector додати:
1. **Tooltips**: Переконайтеся, що всі публічні поля мають [Tooltip]
2. **Headers**: Групуйте схожі налаштування через [Header]
3. **Ranges**: Використовуйте [Range] для числових значень

### Hotkeys для швидкого тестування:
```csharp
// Додати в Update будь-якого менеджера
#if UNITY_EDITOR
void Update()
{
    if (Input.GetKeyDown(KeyCode.F1)) // Швидке лікування
    {
        FindObjectOfType<PlayerHealth>()?.Heal(50f);
    }
    
    if (Input.GetKeyDown(KeyCode.F2)) // Безкінечні патрони
    {
        var weapon = FindObjectOfType<WeaponController>();
        if (weapon != null)
        {
            weapon.GetType().GetField("currentAmmo", 
                System.Reflection.BindingFlags.NonPublic | 
                System.Reflection.BindingFlags.Instance)?.SetValue(weapon, 999);
        }
    }
    
    if (Input.GetKeyDown(KeyCode.F3)) // Швидкий рух
    {
        var movement = FindObjectOfType<PlayerMovement>();
        if (movement != null)
        {
            movement.walkSpeed *= 2f;
            movement.sprintSpeed *= 2f;
        }
    }
}
#endif
```

## 📝 Чеклист швидких виправлень

- [ ] ✅ Виправлено віддачу (MouseLook + WeaponController)
- [ ] ✅ Додано ефекти лікування
- [ ] ✅ Захист від спаму взаємодії  
- [ ] ✅ Оптимізовано PlayerInteraction
- [ ] ✅ Покращено систему патронів
- [ ] ✅ Додано налаштування чутливості
- [ ] ✅ Створено SimpleAudioManager
- [ ] ✅ Додано перевірки на null
- [ ] ✅ Покращено UI відгук
- [ ] ✅ Додано систему пауз
- [ ] ✅ Налаштування FOV
- [ ] ✅ Система статистики

**Загальний час реалізації: 1-2 години**
**Покращення якості: +25-30%**

Ці швидкі виправлення миттєво покращать стабільність та відчуття вашої гри!
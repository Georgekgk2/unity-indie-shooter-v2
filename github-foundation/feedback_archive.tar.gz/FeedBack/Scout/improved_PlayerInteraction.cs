using UnityEngine;
using TMPro; // Для відображення підказки

public class PlayerInteraction : MonoBehaviour
{
    [Header("Interaction Settings")]
    [Tooltip("Відстань, на якій гравець може взаємодіяти з об'єктами.")]
    public float interactionDistance = 3f;
    [Tooltip("Кнопка для взаємодії.")]
    public KeyCode interactionKey = KeyCode.E;
    [Tooltip("Шар(и) об'єктів, з якими можна взаємодіяти.")]
    public LayerMask interactableLayer;
    
    [Header("Performance Settings")]
    [Tooltip("Інтервал між Raycast перевірками (у секундах). Менше значення = частіші перевірки.")]
    [Range(0.01f, 0.5f)]
    public float raycastInterval = 0.1f; // НОВЕ: оптимізація продуктивності

    [Header("UI Settings")]
    [Tooltip("Текстовий елемент для відображення підказки (наприклад, 'Натисніть E, щоб відкрити').")]
    public TextMeshProUGUI interactionPromptText;
    
    [Header("Anti-Spam Settings")]
    [Tooltip("Мінімальний час між взаємодіями (у секундах) для запобігання спаму.")]
    [Range(0.1f, 2f)]
    public float interactionCooldown = 0.3f; // НОВЕ: захист від спаму
    
    // Приватні змінні
    private Camera mainCamera;
    private Interactable currentInteractable; // Об'єкт, на який ми зараз дивимося
    private float lastRaycastTime; // НОВЕ: час останнього Raycast
    private float lastInteractionTime; // НОВЕ: час останньої взаємодії

    void Awake()
    {
        mainCamera = Camera.main;
        if (mainCamera == null)
        {
            Debug.LogError("PlayerInteraction: Main Camera не знайдена. Взаємодія не працюватиме.", this);
            enabled = false;
        }
        
        // Вимикаємо текст підказки на старті
        if (interactionPromptText != null)
        {
            interactionPromptText.gameObject.SetActive(false);
        }
        
        // Ініціалізуємо час
        lastRaycastTime = 0f;
        lastInteractionTime = 0f;
    }

    void Update()
    {
        // ОПТИМІЗОВАНО: Raycast тільки через певні інтервали
        if (Time.time - lastRaycastTime >= raycastInterval)
        {
            CheckForInteractable();
            lastRaycastTime = Time.time;
        }
        
        HandleInteractionInput();
    }

    /// <summary>
    /// Перевіряє, чи є перед гравцем об'єкт, з яким можна взаємодіяти.
    /// ОПТИМІЗОВАНО: викликається тільки через інтервали, а не кожен кадр.
    /// </summary>
    private void CheckForInteractable()
    {
        RaycastHit hit;
        Ray ray = new Ray(mainCamera.transform.position, mainCamera.transform.forward);

        // Випускаємо промінь
        if (Physics.Raycast(ray, out hit, interactionDistance, interactableLayer))
        {
            // Якщо промінь влучив у об'єкт з компонентом Interactable
            if (hit.collider.TryGetComponent(out Interactable interactable))
            {
                // Якщо ми дивимося на новий об'єкт
                if (interactable != currentInteractable)
                {
                    currentInteractable = interactable;
                    UpdateInteractionPrompt();
                }
            }
            else // Якщо влучили в щось, але це не Interactable
            {
                ClearInteraction();
            }
        }
        else // Якщо промінь нікуди не влучив
        {
            ClearInteraction();
        }
    }
    
    /// <summary>
    /// Обробляє натискання кнопки взаємодії.
    /// ПОКРАЩЕНО: додано захист від спаму взаємодій.
    /// </summary>
    private void HandleInteractionInput()
    {
        // Якщо ми дивимося на об'єкт, з яким можна взаємодіяти, і натиснули кнопку E
        if (currentInteractable != null && Input.GetKeyDown(interactionKey))
        {
            // НОВЕ: перевірка кулдауна для запобігання спаму
            if (Time.time - lastInteractionTime >= interactionCooldown)
            {
                currentInteractable.Interact(this.gameObject); // Передаємо себе як "ініціатора"
                lastInteractionTime = Time.time;
                
                // Опціонально: можна додати звуковий ефект чи вібрацію
                Debug.Log($"Interacted with: {currentInteractable.name}");
            }
            else
            {
                Debug.Log("Interaction on cooldown. Please wait.");
            }
        }
    }

    /// <summary>
    /// Оновлює текст підказки для взаємодії.
    /// </summary>
    private void UpdateInteractionPrompt()
    {
        if (interactionPromptText != null)
        {
            interactionPromptText.text = $"[{interactionKey}] {currentInteractable.interactionPrompt}";
            interactionPromptText.gameObject.SetActive(true);
        }
    }

    /// <summary>
    /// Приховує підказку та очищує поточний об'єкт для взаємодії.
    /// </summary>
    private void ClearInteraction()
    {
        if (currentInteractable != null)
        {
            currentInteractable = null;
            if (interactionPromptText != null)
            {
                interactionPromptText.gameObject.SetActive(false);
            }
        }
    }
    
    /// <summary>
    /// НОВІ ПУБЛІЧНІ МЕТОДИ для налаштування та діагностики
    /// </summary>
    
    /// <summary>
    /// Дозволяє динамічно змінювати інтервал Raycast під час гри.
    /// </summary>
    public void SetRaycastInterval(float newInterval)
    {
        raycastInterval = Mathf.Clamp(newInterval, 0.01f, 0.5f);
        Debug.Log($"Raycast interval set to: {raycastInterval}s");
    }
    
    /// <summary>
    /// Дозволяє динамічно змінювати кулдаун взаємодії.
    /// </summary>
    public void SetInteractionCooldown(float newCooldown)
    {
        interactionCooldown = Mathf.Clamp(newCooldown, 0.1f, 2f);
        Debug.Log($"Interaction cooldown set to: {interactionCooldown}s");
    }
    
    /// <summary>
    /// Повертає, чи є поточний об'єкт для взаємодії.
    /// </summary>
    public bool HasInteractableInSight()
    {
        return currentInteractable != null;
    }
    
    /// <summary>
    /// Повертає поточний об'єкт для взаємодії (може бути null).
    /// </summary>
    public Interactable GetCurrentInteractable()
    {
        return currentInteractable;
    }
    
    /// <summary>
    /// Примусово очищає поточну взаємодію (корисно для випадків, коли об'єкт знищується).
    /// </summary>
    public void ForceClearInteraction()
    {
        ClearInteraction();
    }
    
    /// <summary>
    /// Повертає, чи можна зараз взаємодіяти (чи не на кулдауні).
    /// </summary>
    public bool CanInteract()
    {
        return Time.time - lastInteractionTime >= interactionCooldown;
    }
    
#if UNITY_EDITOR
    /// <summary>
    /// Відображає Raycast у режимі редактора для налагодження.
    /// </summary>
    void OnDrawGizmosSelected()
    {
        if (mainCamera != null)
        {
            Gizmos.color = currentInteractable != null ? Color.green : Color.red;
            Gizmos.DrawLine(mainCamera.transform.position, 
                           mainCamera.transform.position + mainCamera.transform.forward * interactionDistance);
        }
    }
#endif
}
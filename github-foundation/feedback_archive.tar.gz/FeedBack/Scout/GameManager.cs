using UnityEngine;
using UnityEngine.SceneManagement;
using System.Collections;

/// <summary>
/// Централізований менеджер гри - управляє станом гри, сценами та глобальними налаштуваннями
/// </summary>
public class GameManager : MonoBehaviour
{
    [Header("Game State Settings")]
    [Tooltip("Початковий стан гри")]
    public GameState initialGameState = GameState.Playing;
    [Tooltip("Чи можна ставити гру на паузу?")]
    public bool canPause = true;
    [Tooltip("Клавіша для паузи")]
    public KeyCode pauseKey = KeyCode.Escape;
    
    [Header("Player Settings")]
    [Tooltip("Префаб гравця для спавну")]
    public GameObject playerPrefab;
    [Tooltip("Початкова позиція спавну")]
    public Transform defaultSpawnPoint;
    [Tooltip("Максимальна кількість життів (0 = необмежено)")]
    [Range(0, 10)]
    public int maxLives = 3;
    
    [Header("Scene Management")]
    [Tooltip("Назва головного меню сцени")]
    public string mainMenuSceneName = "MainMenu";
    [Tooltip("Назва сцени завантаження")]
    public string loadingSceneName = "Loading";
    [Tooltip("Чи перезавантажувати сцену при смерті гравця?")]
    public bool reloadSceneOnDeath = false;
    
    [Header("Game Over Settings")]
    [Tooltip("Затримка перед Game Over екраном (секунди)")]
    [Range(0f, 5f)]
    public float gameOverDelay = 2f;
    [Tooltip("Чи показувати статистику при Game Over?")]
    public bool showStatsOnGameOver = true;
    
    [Header("Debug Settings")]
    [Tooltip("Показувати debug інформацію в консолі")]
    public bool enableDebugLogging = true;
    [Tooltip("Показувати стан гри на екрані")]
    public bool showGameStateOnScreen = false;

    // Приватні змінні
    private GameState currentGameState;
    private GameState previousGameState;
    private GameObject currentPlayer;
    private Vector3 currentCheckpointPosition;
    private int currentLives;
    private float gameStartTime;
    private bool isTransitioning = false;

    // Статистика гри
    private int totalDeaths = 0;
    private int totalCheckpoints = 0;
    private float totalPlayTime = 0f;

    // Singleton pattern
    public static GameManager Instance { get; private set; }

    // Події (публічні для підписки)
    public System.Action<GameState> OnGameStateChanged;
    public System.Action<bool> OnGamePaused;
    public System.Action OnPlayerSpawned;
    public System.Action OnGameOver;
    public System.Action OnVictory;

    void Awake()
    {
        // Реалізація Singleton
        if (Instance != null && Instance != this)
        {
            Destroy(gameObject);
            return;
        }
        Instance = this;
        DontDestroyOnLoad(gameObject);

        // Ініціалізація
        InitializeGame();
    }

    void Start()
    {
        // Підписуємося на події
        SubscribeToEvents();
        
        // Встановлюємо початковий стан
        ChangeGameState(initialGameState);
        
        // Записуємо час початку гри
        gameStartTime = Time.time;
        
        if (enableDebugLogging)
        {
            Debug.Log("GameManager: Гра ініціалізована.");
        }
    }

    void Update()
    {
        HandleInput();
        UpdateGameTime();
        
        // Debug інформація на екрані
        if (showGameStateOnScreen)
        {
            DisplayGameStateOnScreen();
        }
    }

    void OnDestroy()
    {
        if (Instance == this)
        {
            UnsubscribeFromEvents();
            Instance = null;
        }
    }

    /// <summary>
    /// Ініціалізує базові налаштування гри
    /// </summary>
    private void InitializeGame()
    {
        currentGameState = GameState.Loading;
        previousGameState = GameState.Loading;
        currentLives = maxLives;
        currentCheckpointPosition = defaultSpawnPoint != null ? defaultSpawnPoint.position : Vector3.zero;
        
        // Налаштування Unity
        Application.targetFrameRate = 60;
        QualitySettings.vSyncCount = 1;
    }

    /// <summary>
    /// Підписується на глобальні події
    /// </summary>
    private void SubscribeToEvents()
    {
        GameEvents.OnPlayerDied += HandlePlayerDeath;
        GameEvents.OnCheckpointReached += HandleCheckpointReached;
        GameEvents.OnPlayerDamaged += HandlePlayerDamaged;
        GameEvents.OnPlayerHealed += HandlePlayerHealed;
    }

    /// <summary>
    /// Відписується від глобальних подій
    /// </summary>
    private void UnsubscribeFromEvents()
    {
        GameEvents.OnPlayerDied -= HandlePlayerDeath;
        GameEvents.OnCheckpointReached -= HandleCheckpointReached;
        GameEvents.OnPlayerDamaged -= HandlePlayerDamaged;
        GameEvents.OnPlayerHealed -= HandlePlayerHealed;
    }

    /// <summary>
    /// Обробляє введення гравця
    /// </summary>
    private void HandleInput()
    {
        // Обробка паузи
        if (canPause && Input.GetKeyDown(pauseKey))
        {
            if (currentGameState == GameState.Playing)
            {
                PauseGame();
            }
            else if (currentGameState == GameState.Paused)
            {
                ResumeGame();
            }
        }

        // Debug команди (тільки в режимі розробки)
        #if UNITY_EDITOR
        if (Input.GetKeyDown(KeyCode.F1))
        {
            PrintGameStats();
        }
        if (Input.GetKeyDown(KeyCode.F2))
        {
            RespawnPlayer();
        }
        if (Input.GetKeyDown(KeyCode.F3))
        {
            ChangeGameState(GameState.GameOver);
        }
        #endif
    }

    /// <summary>
    /// Оновлює час гри
    /// </summary>
    private void UpdateGameTime()
    {
        if (currentGameState == GameState.Playing)
        {
            totalPlayTime += Time.deltaTime;
        }
    }

    /// <summary>
    /// Змінює стан гри
    /// </summary>
    public void ChangeGameState(GameState newState)
    {
        if (currentGameState == newState || isTransitioning) return;

        previousGameState = currentGameState;
        currentGameState = newState;

        if (enableDebugLogging)
        {
            Debug.Log($"GameManager: Стан гри змінено з {previousGameState} на {currentGameState}");
        }

        // Обробка конкретних станів
        switch (currentGameState)
        {
            case GameState.Playing:
                HandlePlayingState();
                break;
            case GameState.Paused:
                HandlePausedState();
                break;
            case GameState.GameOver:
                HandleGameOverState();
                break;
            case GameState.Victory:
                HandleVictoryState();
                break;
            case GameState.MainMenu:
                HandleMainMenuState();
                break;
        }

        // Повідомляємо про зміну стану
        OnGameStateChanged?.Invoke(currentGameState);
        GameEvents.SafeInvoke(GameEvents.OnGameStateChanged, currentGameState, previousGameState);
    }

    /// <summary>
    /// Обробка стану "Гра"
    /// </summary>
    private void HandlePlayingState()
    {
        Time.timeScale = 1f;
        GameEvents.SafeInvoke(GameEvents.OnCursorVisibilityChanged, false);
        
        // Спавн гравця, якщо потрібно
        if (currentPlayer == null)
        {
            SpawnPlayer();
        }
    }

    /// <summary>
    /// Обробка стану "Пауза"
    /// </summary>
    private void HandlePausedState()
    {
        Time.timeScale = 0f;
        GameEvents.SafeInvoke(GameEvents.OnCursorVisibilityChanged, true);
        OnGamePaused?.Invoke(true);
        GameEvents.SafeInvoke(GameEvents.OnGamePaused, true);
    }

    /// <summary>
    /// Обробка стану "Game Over"
    /// </summary>
    private void HandleGameOverState()
    {
        Time.timeScale = 1f;
        GameEvents.SafeInvoke(GameEvents.OnCursorVisibilityChanged, true);
        OnGameOver?.Invoke();
        
        if (showStatsOnGameOver)
        {
            StartCoroutine(ShowGameOverStatsDelayed());
        }
    }

    /// <summary>
    /// Обробка стану "Перемога"
    /// </summary>
    private void HandleVictoryState()
    {
        Time.timeScale = 1f;
        GameEvents.SafeInvoke(GameEvents.OnCursorVisibilityChanged, true);
        OnVictory?.Invoke();
        PrintGameStats();
    }

    /// <summary>
    /// Обробка стану "Головне меню"
    /// </summary>
    private void HandleMainMenuState()
    {
        Time.timeScale = 1f;
        GameEvents.SafeInvoke(GameEvents.OnCursorVisibilityChanged, true);
    }

    /// <summary>
    /// Ставить гру на паузу
    /// </summary>
    public void PauseGame()
    {
        if (currentGameState == GameState.Playing)
        {
            ChangeGameState(GameState.Paused);
        }
    }

    /// <summary>
    /// Відновлює гру з паузи
    /// </summary>
    public void ResumeGame()
    {
        if (currentGameState == GameState.Paused)
        {
            ChangeGameState(GameState.Playing);
            OnGamePaused?.Invoke(false);
            GameEvents.SafeInvoke(GameEvents.OnGamePaused, false);
        }
    }

    /// <summary>
    /// Спавн гравця
    /// </summary>
    public void SpawnPlayer()
    {
        if (playerPrefab == null)
        {
            Debug.LogWarning("GameManager: Player Prefab не призначено!");
            return;
        }

        // Знищуємо старого гравця, якщо є
        if (currentPlayer != null)
        {
            Destroy(currentPlayer);
        }

        // Створюємо нового гравця
        Vector3 spawnPosition = currentCheckpointPosition;
        currentPlayer = Instantiate(playerPrefab, spawnPosition, Quaternion.identity);
        
        OnPlayerSpawned?.Invoke();
        GameEvents.SafeInvoke(GameEvents.OnPlayerRespawned, spawnPosition);
        
        if (enableDebugLogging)
        {
            Debug.Log($"GameManager: Гравець створений на позиції {spawnPosition}");
        }
    }

    /// <summary>
    /// Відродження гравця
    /// </summary>
    public void RespawnPlayer()
    {
        if (currentGameState == GameState.GameOver) return;

        SpawnPlayer();
        ChangeGameState(GameState.Playing);
    }

    /// <summary>
    /// Обробка смерті гравця
    /// </summary>
    private void HandlePlayerDeath()
    {
        totalDeaths++;
        
        if (maxLives > 0)
        {
            currentLives--;
            if (currentLives <= 0)
            {
                StartCoroutine(GameOverDelayed());
                return;
            }
        }

        if (reloadSceneOnDeath)
        {
            ReloadCurrentScene();
        }
        else
        {
            StartCoroutine(RespawnPlayerDelayed(2f));
        }
    }

    /// <summary>
    /// Обробка досягнення чекпоінту
    /// </summary>
    private void HandleCheckpointReached(string checkpointId, Vector3 position)
    {
        currentCheckpointPosition = position;
        totalCheckpoints++;
        
        if (enableDebugLogging)
        {
            Debug.Log($"GameManager: Чекпоінт досягнуто - {checkpointId} на позиції {position}");
        }
    }

    /// <summary>
    /// Обробка отримання урону гравцем
    /// </summary>
    private void HandlePlayerDamaged(int damage, int remainingHealth, GameObject source)
    {
        // Тут можна додати додаткову логіку при отриманні урону
    }

    /// <summary>
    /// Обробка лікування гравця
    /// </summary>
    private void HandlePlayerHealed(int healAmount, int newHealth)
    {
        // Тут можна додати додаткову логіку при лікуванні
    }

    /// <summary>
    /// Корутина для затримки Game Over
    /// </summary>
    private IEnumerator GameOverDelayed()
    {
        yield return new WaitForSeconds(gameOverDelay);
        ChangeGameState(GameState.GameOver);
    }

    /// <summary>
    /// Корутина для затримки респавну
    /// </summary>
    private IEnumerator RespawnPlayerDelayed(float delay)
    {
        yield return new WaitForSeconds(delay);
        RespawnPlayer();
    }

    /// <summary>
    /// Корутина для показу статистики Game Over
    /// </summary>
    private IEnumerator ShowGameOverStatsDelayed()
    {
        yield return new WaitForSeconds(1f);
        PrintGameStats();
    }

    /// <summary>
    /// Перезавантаження поточної сцени
    /// </summary>
    public void ReloadCurrentScene()
    {
        isTransitioning = true;
        Scene currentScene = SceneManager.GetActiveScene();
        SceneManager.LoadScene(currentScene.name);
    }

    /// <summary>
    /// Завантаження сцени головного меню
    /// </summary>
    public void LoadMainMenu()
    {
        isTransitioning = true;
        ChangeGameState(GameState.MainMenu);
        SceneManager.LoadScene(mainMenuSceneName);
    }

    /// <summary>
    /// Завантаження нової гри
    /// </summary>
    public void StartNewGame()
    {
        // Скидаємо статистику
        totalDeaths = 0;
        totalCheckpoints = 0;
        totalPlayTime = 0f;
        currentLives = maxLives;
        gameStartTime = Time.time;
        
        ChangeGameState(GameState.Playing);
    }

    /// <summary>
    /// Вихід з гри
    /// </summary>
    public void QuitGame()
    {
        if (enableDebugLogging)
        {
            Debug.Log("GameManager: Вихід з гри.");
        }

        #if UNITY_EDITOR
        UnityEditor.EditorApplication.isPlaying = false;
        #else
        Application.Quit();
        #endif
    }

    /// <summary>
    /// Виводить статистику гри
    /// </summary>
    public void PrintGameStats()
    {
        float totalTime = Time.time - gameStartTime;
        string stats = $"СТАТИСТИКА ГРИ:\n" +
                      $"- Час гри: {totalTime:F1} сек\n" +
                      $"- Час в грі: {totalPlayTime:F1} сек\n" +
                      $"- Смерті: {totalDeaths}\n" +
                      $"- Чекпоінти: {totalCheckpoints}\n" +
                      $"- Життя: {currentLives}/{maxLives}\n" +
                      $"- Поточний стан: {currentGameState}";
        
        Debug.Log(stats);
        GameEvents.SafeInvoke(GameEvents.OnShowPlayerMessage, stats, 5f, MessageType.Info);
    }

    /// <summary>
    /// Відображає стан гри на екрані (для debug)
    /// </summary>
    private void DisplayGameStateOnScreen()
    {
        // Тут можна додати код для відображення на екрані
        // Наприклад, через OnGUI або UI Text
    }

    // Публічні властивості для отримання інформації
    public GameState CurrentGameState => currentGameState;
    public bool IsGamePaused => currentGameState == GameState.Paused;
    public bool IsGamePlaying => currentGameState == GameState.Playing;
    public int CurrentLives => currentLives;
    public float TotalPlayTime => totalPlayTime;
    public int TotalDeaths => totalDeaths;
    public int TotalCheckpoints => totalCheckpoints;
    public GameObject CurrentPlayer => currentPlayer;
    public Vector3 CurrentCheckpointPosition => currentCheckpointPosition;
}
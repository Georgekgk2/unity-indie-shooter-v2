// ObjectPool.cs - Система пулінгу об'єктів
using UnityEngine;
using System.Collections.Generic;

public class ObjectPool : MonoBehaviour
{
    [System.Serializable]
    public class Pool
    {
        public string tag;
        public GameObject prefab;
        public int size;
    }
    
    public static ObjectPool Instance;
    public List<Pool> pools;
    
    private Dictionary<string, Queue<GameObject>> poolDictionary;
    
    void Awake()
    {
        Instance = this;
        InitializePools();
    }
    
    void InitializePools()
    {
        poolDictionary = new Dictionary<string, Queue<GameObject>>();
        
        foreach (Pool pool in pools)
        {
            Queue<GameObject> objectPool = new Queue<GameObject>();
            
            for (int i = 0; i < pool.size; i++)
            {
                GameObject obj = Instantiate(pool.prefab);
                obj.SetActive(false);
                obj.transform.SetParent(transform);
                objectPool.Enqueue(obj);
            }
            
            poolDictionary.Add(pool.tag, objectPool);
        }
    }
    
    public GameObject SpawnFromPool(string tag, Vector3 position, Quaternion rotation)
    {
        if (!poolDictionary.ContainsKey(tag))
        {
            Debug.LogWarning($"Pool with tag {tag} doesn't exist.");
            return null;
        }
        
        GameObject objectToSpawn = poolDictionary[tag].Dequeue();
        
        objectToSpawn.SetActive(true);
        objectToSpawn.transform.position = position;
        objectToSpawn.transform.rotation = rotation;
        
        poolDictionary[tag].Enqueue(objectToSpawn);
        
        return objectToSpawn;
    }
}

// PooledBullet.cs - Оновлена версія Bullet для використання з пулом
public class PooledBullet : MonoBehaviour
{
    [SerializeField] private float lifeTime = 3f;
    [SerializeField] private GameObject hitEffectPrefab;
    [SerializeField] private float damage = 10f;
    
    private float spawnTime;
    private Rigidbody rb;
    private TrailRenderer trail;
    
    void Awake()
    {
        rb = GetComponent<Rigidbody>();
        trail = GetComponent<TrailRenderer>();
    }
    
    void OnEnable()
    {
        spawnTime = Time.time;
        if (trail != null) trail.Clear();
    }
    
    void Update()
    {
        // Автоматично деактивуємо після закінчення часу життя
        if (Time.time - spawnTime > lifeTime)
        {
            ReturnToPool();
        }
    }
    
    void OnCollisionEnter(Collision collision)
    {
        // Спавнимо ефект удару через пул
        if (hitEffectPrefab != null)
        {
            ObjectPool.Instance.SpawnFromPool("HitEffect", 
                collision.contacts[0].point, 
                Quaternion.LookRotation(collision.contacts[0].normal));
        }
        
        // Завдаємо урон
        var health = collision.gameObject.GetComponent<HealthSystem>();
        if (health != null)
        {
            health.TakeDamage(damage, gameObject);
        }
        
        ReturnToPool();
    }
    
    private void ReturnToPool()
    {
        rb.velocity = Vector3.zero;
        rb.angularVelocity = Vector3.zero;
        gameObject.SetActive(false);
    }
}

// LODManager.cs - Динамічне керування рівнями деталізації
public class LODManager : MonoBehaviour
{
    [System.Serializable]
    public class LODSettings
    {
        public float distance = 50f;
        public int maxBones = 30;
        public bool enableShadows = true;
        public float animationQuality = 1f;
    }
    
    [SerializeField] private LODSettings[] lodLevels;
    [SerializeField] private SkinnedMeshRenderer[] meshRenderers;
    [SerializeField] private Animator animator;
    
    private Transform playerTransform;
    private int currentLOD = -1;
    
    void Start()
    {
        playerTransform = Camera.main.transform;
        if (animator == null) animator = GetComponent<Animator>();
    }
    
    void Update()
    {
        float distance = Vector3.Distance(transform.position, playerTransform.position);
        int targetLOD = GetLODLevel(distance);
        
        if (targetLOD != currentLOD)
        {
            ApplyLOD(targetLOD);
            currentLOD = targetLOD;
        }
    }
    
    private int GetLODLevel(float distance)
    {
        for (int i = 0; i < lodLevels.Length; i++)
        {
            if (distance <= lodLevels[i].distance)
                return i;
        }
        return lodLevels.Length - 1;
    }
    
    private void ApplyLOD(int level)
    {
        if (level < 0 || level >= lodLevels.Length) return;
        
        LODSettings settings = lodLevels[level];
        
        // Налаштування тіней
        foreach (var renderer in meshRenderers)
        {
            renderer.shadowCastingMode = settings.enableShadows ? 
                UnityEngine.Rendering.ShadowCastingMode.On : 
                UnityEngine.Rendering.ShadowCastingMode.Off;
        }
        
        // Налаштування анімації
        if (animator != null)
        {
            animator.speed = settings.animationQuality;
            
            // На великій відстані можна вимкнути деякі шари анімації
            if (level > 1)
            {
                animator.SetLayerWeight(1, 0); // Вимикаємо додаткові шари
            }
        }
    }
}
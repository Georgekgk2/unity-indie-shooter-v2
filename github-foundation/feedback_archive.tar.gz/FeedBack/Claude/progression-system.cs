// PlayerProgression.cs - Система прогресії гравця
using UnityEngine;
using System.Collections.Generic;

[System.Serializable]
public class PlayerStats
{
    public int level = 1;
    public int experience = 0;
    public int skillPoints = 0;
    
    // Базові характеристики
    public float healthMultiplier = 1f;
    public float staminaMultiplier = 1f;
    public float damageMultiplier = 1f;
    public float reloadSpeedMultiplier = 1f;
    public float movementSpeedMultiplier = 1f;
}

public class PlayerProgression : MonoBehaviour
{
    [Header("Progression Settings")]
    [SerializeField] private AnimationCurve experienceCurve;
    [SerializeField] private int maxLevel = 50;
    [SerializeField] private int skillPointsPerLevel = 1;
    
    [Header("Current Stats")]
    [SerializeField] private PlayerStats currentStats;
    
    [Header("Unlocked Perks")]
    [SerializeField] private List<string> unlockedPerkIDs = new List<string>();
    
    public PlayerStats Stats => currentStats;
    
    // Події прогресії
    public static event System.Action<int> OnLevelUp;
    public static event System.Action<int> OnExperienceGained;
    public static event System.Action<Perk> OnPerkUnlocked;
    
    void Start()
    {
        LoadProgression();
        ApplyStatsToPlayer();
    }
    
    public void AddExperience(int amount)
    {
        currentStats.experience += amount;
        OnExperienceGained?.Invoke(amount);
        
        CheckLevelUp();
        SaveProgression();
    }
    
    private void CheckLevelUp()
    {
        int requiredExp = GetRequiredExperience(currentStats.level);
        
        while (currentStats.experience >= requiredExp && currentStats.level < maxLevel)
        {
            currentStats.experience -= requiredExp;
            currentStats.level++;
            currentStats.skillPoints += skillPointsPerLevel;
            
            OnLevelUp?.Invoke(currentStats.level);
            
            requiredExp = GetRequiredExperience(currentStats.level);
        }
    }
    
    private int GetRequiredExperience(int level)
    {
        return Mathf.RoundToInt(experienceCurve.Evaluate(level) * 100);
    }
    
    public bool UnlockPerk(Perk perk)
    {
        if (currentStats.skillPoints < perk.cost || unlockedPerkIDs.Contains(perk.id))
            return false;
            
        currentStats.skillPoints -= perk.cost;
        unlockedPerkIDs.Add(perk.id);
        
        ApplyPerk(perk);
        OnPerkUnlocked?.Invoke(perk);
        SaveProgression();
        
        return true;
    }
    
    private void ApplyPerk(Perk perk)
    {
        foreach (var effect in perk.effects)
        {
            switch (effect.type)
            {
                case PerkEffectType.HealthBonus:
                    currentStats.healthMultiplier += effect.value;
                    break;
                case PerkEffectType.StaminaBonus:
                    currentStats.staminaMultiplier += effect.value;
                    break;
                case PerkEffectType.DamageBonus:
                    currentStats.damageMultiplier += effect.value;
                    break;
                case PerkEffectType.ReloadSpeed:
                    currentStats.reloadSpeedMultiplier += effect.value;
                    break;
                case PerkEffectType.MovementSpeed:
                    currentStats.movementSpeedMultiplier += effect.value;
                    break;
            }
        }
        
        ApplyStatsToPlayer();
    }
    
    private void ApplyStatsToPlayer()
    {
        // Застосовуємо множники до компонентів гравця
        var health = GetComponent<PlayerHealth>();
        if (health != null)
        {
            // health.SetMaxHealthMultiplier(currentStats.healthMultiplier);
        }
        
        var movement = GetComponent<PlayerMovement>();
        if (movement != null)
        {
            // movement.SetSpeedMultiplier(currentStats.movementSpeedMultiplier);
        }
    }
    
    private void SaveProgression()
    {
        PlayerPrefs.SetInt("PlayerLevel", currentStats.level);
        PlayerPrefs.SetInt("PlayerExperience", currentStats.experience);
        PlayerPrefs.SetInt("PlayerSkillPoints", currentStats.skillPoints);
        
        // Зберігаємо перки
        PlayerPrefs.SetString("UnlockedPerks", string.Join(",", unlockedPerkIDs));
        
        PlayerPrefs.Save();
    }
    
    private void LoadProgression()
    {
        currentStats.level = PlayerPrefs.GetInt("PlayerLevel", 1);
        currentStats.experience = PlayerPrefs.GetInt("PlayerExperience", 0);
        currentStats.skillPoints = PlayerPrefs.GetInt("PlayerSkillPoints", 0);
        
        string perksString = PlayerPrefs.GetString("UnlockedPerks", "");
        if (!string.IsNullOrEmpty(perksString))
        {
            unlockedPerkIDs.AddRange(perksString.Split(','));
        }
    }
}

// Perk.cs - ScriptableObject для перків
[CreateAssetMenu(fileName = "New Perk", menuName = "Game/Perk")]
public class Perk : ScriptableObject
{
    public string id;
    public string perkName;
    public string description;
    public Sprite icon;
    public int cost = 1;
    public int requiredLevel = 1;
    public List<string> requiredPerks = new List<string>();
    
    public List<PerkEffect> effects = new List<PerkEffect>();
}

[System.Serializable]
public class PerkEffect
{
    public PerkEffectType type;
    public float value;
}

public enum PerkEffectType
{
    HealthBonus,
    StaminaBonus,
    DamageBonus,
    ReloadSpeed,
    MovementSpeed,
    CriticalChance,
    HeadshotDamage,
    ExplosiveAmmo,
    LifeSteal,
    DashCharges
}

// PerkTree.cs - UI для дерева перків
public class PerkTree : MonoBehaviour
{
    [Header("Perk Categories")]
    [SerializeField] private PerkCategory[] categories;
    
    [Header("UI References")]
    [SerializeField] private GameObject perkNodePrefab;
    [SerializeField] private Transform perkContainer;
    [SerializeField] private TMPro.TextMeshProUGUI skillPointsText;
    
    private PlayerProgression progression;
    private Dictionary<string, PerkNode> perkNodes = new Dictionary<string, PerkNode>();
    
    [System.Serializable]
    public class PerkCategory
    {
        public string name;
        public Color color;
        public List<Perk> perks;
    }
    
    void Start()
    {
        progression = FindObjectOfType<PlayerProgression>();
        BuildPerkTree();
        UpdateUI();
    }
    
    private void BuildPerkTree()
    {
        foreach (var category in categories)
        {
            foreach (var perk in category.perks)
            {
                GameObject nodeObj = Instantiate(perkNodePrefab, perkContainer);
                PerkNode node = nodeObj.GetComponent<PerkNode>();
                
                node.Initialize(perk, category.color);
                node.OnPerkSelected += TryUnlockPerk;
                
                perkNodes[perk.id] = node;
            }
        }
        
        // З'єднуємо вузли лініями відповідно до вимог
        ConnectPerkNodes();
    }
    
    private void TryUnlockPerk(Perk perk)
    {
        if (CanUnlockPerk(perk) && progression.UnlockPerk(perk))
        {
            UpdateUI();
        }
    }
    
    private bool CanUnlockPerk(Perk perk)
    {
        // Перевірка рівня
        if (progression.Stats.level < perk.requiredLevel)
            return false;
            
        // Перевірка необхідних перків
        foreach (string requiredPerkID in perk.requiredPerks)
        {
            if (!progression.unlockedPerkIDs.Contains(requiredPerkID))
                return false;
        }
        
        return progression.Stats.skillPoints >= perk.cost;
    }
    
    private void UpdateUI()
    {
        skillPointsText.text = $"Skill Points: {progression.Stats.skillPoints}";
        
        foreach (var node in perkNodes.Values)
        {
            bool isUnlocked = progression.unlockedPerkIDs.Contains(node.Perk.id);
            bool canUnlock = !isUnlocked && CanUnlockPerk(node.Perk);
            
            node.UpdateState(isUnlocked, canUnlock);
        }
    }
}
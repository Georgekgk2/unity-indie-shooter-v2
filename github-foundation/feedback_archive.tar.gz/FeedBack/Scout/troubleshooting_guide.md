# 🛠️ Вирішення проблем при впровадженні

## 🚨 Частіші проблеми та рішення

### 1. 💥 Віддача не працює

#### Симптоми:
- Стрільба є, але камера не рухається
- Консоль: "MouseLook не знайдено"

#### Рішення:
```csharp
// 1. Перевірте у WeaponController → mouseLook поле заповнене?
// 2. Якщо null, тоді в Awake() додайте:
mouseLook = GetComponentInParent<MouseLook>();
if (mouseLook == null)
{
    Debug.LogError("MouseLook компонент не знайдено!");
}

// 3. Перевірте recoil налаштування > 0:
recoilX > 0, recoilY > 0
```

### 2. ⚡ Raycast оптимізація не працює

#### Симптоми:
- FPS все ще падає при наведенні на об'єкти
- Консоль: безкінечні повідомлення

#### Рішення:
```csharp
// Перевірте в PlayerInteraction налаштування:
raycastInterval = 0.1f  // НЕ 0!
interactionCooldown = 0.3f

// Якщо проблема залишається:
void Update()
{
    // Переконайтеся що ця перевірка є:
    if (Time.time - lastRaycastTime >= raycastInterval)
    {
        CheckForInteractable();
        lastRaycastTime = Time.time;
    }
}
```

### 3. 🎯 BulletPool помилки

#### Симптоми:
- "BulletPool.Instance is null"
- Кулі не стріляють
- GC спайки як і раніше

#### Рішення:
```csharp
// 1. Перевірте GameObject "BulletPool" створено?
// 2. Перевірте bulletPrefab призначено?
// 3. Перевірте prefab має BulletPoolItem компонент?

// 4. У WeaponController.Shoot() переконайтеся:
GameObject bullet = BulletPool.Instance?.GetBullet();
if (bullet != null)
{
    bullet.transform.position = bulletSpawnPoint.position;
    bullet.transform.rotation = bulletRotation;
    // Налаштування фізики...
}
```

### 4. 🎨 UI ефекти не показуються

#### Симптоми:
- Урон є, але спалаху немає
- Консоль: "Image is null"

#### Рішення:
```
1. Створіть UI елементи:
   Canvas → UI → Image (HealFlashImage)
   Canvas → UI → Image (LowHealthWarningImage)

2. Налаштуйте Image:
   - Color: Alpha = 0 (прозорий)
   - Raycast Target: false
   - Anchors: Stretch full screen

3. Призначте в CameraEffects Inspector
```

### 5. 📡 Events не спрацьовують

#### Симптоми:
- Урон є, але ефекти не показуються
- Консоль: тиша

#### Рішення:
```csharp
// 1. Перевірте підписку в CameraEffects:
void Start()
{
    GameEvents.OnPlayerDamaged += HandleDamage;
}

void OnDestroy()
{
    GameEvents.OnPlayerDamaged -= HandleDamage;  // Важливо!
}

// 2. Перевірте виклик події в PlayerHealth:
GameEvents.SafeInvoke(GameEvents.OnPlayerDamaged, damage, currentHealth, damageSource);
```

### 6. 🎮 GameManager конфлікти

#### Симптоми:
- "Another GameManager already exists"
- Дублікати об'єктів

#### Рішення:
```csharp
// Перевірте що тільки ОДИН GameObject має GameManager компонент
// Видаліть дублікати якщо є

// Переконайтеся що в GameManager.Awake():
if (Instance != null && Instance != this)
{
    Destroy(gameObject);  // Це має спрацювати
    return;
}
```

### 7. 🐛 Компіляція помилки

#### Симптоми:
- Unity не може скомпілювати
- Червоні помилки у консолі

#### Рішення:
```csharp
// 1. Перевірте using директиви:
using UnityEngine;
using System.Collections;
using System.Collections.Generic;

// 2. Видаліть СТАРІ скрипти перед додаванням нових
// 3. Restart Unity Editor
// 4. Clear Console та Recompile
```

---

## 🔍 Діагностика покроково

### Перевірка 1: Віддача
1. ▶️ Play Mode
2. 🔫 Стреляйте
3. 👀 Камера рухається? → ✅ OK | ❌ Див. пункт 1

### Перевірка 2: Взаємодії  
1. 🚶‍♂️ Підійдіть до двері/об'єкту
2. 👁️ Підказка з'являється? → ✅ OK | ❌ Див. пункт 2
3. ⌨️ Натисніть E
4. 🔄 Взаємодія працює? → ✅ OK | ❌ Див. пункт 2

### Перевірка 3: Ефекти
1. 💔 Отримайте урон
2. 🔴 Червоний спалах? → ✅ OK | ❌ Див. пункт 4
3. 💚 Полікуйтеся  
4. 🟢 Зелений ефект? → ✅ OK | ❌ Див. пункт 4

### Перевірка 4: Продуктивність
1. 📊 Profiler → Memory
2. 🔫 Стреляйте 20+ раз швидко
3. 📈 GC спайки мінімальні? → ✅ OK | ❌ Див. пункт 3

---

## 🆘 Критичні помилки

### "The script class cannot be found"
```
Рішення:
1. Assets → Reimport All
2. Restart Unity
3. Перевірте що файл .cs у правильній папці
```

### "Missing MonoBehaviour"  
```
Рішення:
1. Знайдіть GameObject з проблемою
2. Remove Component (старий)
3. Add Component (новий improved_)
4. Відновіть налаштування
```

### "NullReferenceException"
```
Рішення:
1. Перевірте всі посилання у Inspector
2. playerBody, playerCamera, bulletPrefab тощо
3. Переконайтеся що Singleton правильно ініціалізований
```

---

## 📞 Швидка допомога

### ✅ Якщо все працює:
- Віддача є ✓
- Взаємодії плавні ✓  
- Ефекти показуються ✓
- Консоль без помилок ✓
→ **Вітаємо! Впровадження успішне!** 🎉

### ❌ Якщо щось не працює:
1. **Backup відновити** - повернутися до робочої версії
2. **Почати заново** - виконати кроки уважніше
3. **Поетапно** - впроваджувати по одному компоненту

---

## 🎯 Найважливіше

**Не впроваджуйте все одразу!**
1. Спочатку - тільки віддача
2. Потім - взаємодії  
3. Потім - ефекти
4. Потім - нові системи

**Після кожного кроку - тестуйте!**

---

*Пам'ятайте: краще працююча проста версія, ніж зламана складна!* 🛡️
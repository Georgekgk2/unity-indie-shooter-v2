# ⚡ Критичні виправлення (10-15 хвилин)

## 🎯 Тільки найважливіші зміни

### 1. 🔧 Виправлення відбою зброї (2 хвилини)

**Проблема:** Відбій обчислюється але НЕ впливає на камеру

**MouseLook.cs** - додай цей метод:
```csharp
public void ApplyRecoil(float recoilX, float recoilY)
{
    xRotation -= recoilY;
    transform.Rotate(Vector3.up * recoilX);
}
```

**WeaponController.cs** - знайди `UpdateRecoil()` і замініть:
```csharp
void UpdateRecoil()
{
    targetRecoil = Vector3.Lerp(targetRecoil, Vector3.zero, recoilReturnSpeed * Time.deltaTime);
    currentRecoil = Vector3.Slerp(currentRecoil, targetRecoil, recoilSpeed * Time.deltaTime);
    
    // ДОДАЙ ЦЮ ЛІНІЮ:
    mouseLook.ApplyRecoil(currentRecoil.x, currentRecoil.y);
}
```

---

### 2. 🚀 Оптимізація взаємодії (3 хвилини)

**Проблема:** Raycast кожен кадр = лаги

**PlayerInteraction.cs** - додай на початок класу:
```csharp
[SerializeField] private float raycastInterval = 0.1f;
[SerializeField] private float interactionCooldown = 0.2f;
private float lastRaycastTime;
private float lastInteractionTime;
```

**Update()** - замініть весь метод:
```csharp
void Update()
{
    if (Time.time - lastRaycastTime >= raycastInterval)
    {
        CheckForInteractable();
        lastRaycastTime = Time.time;
    }

    if (Input.GetKeyDown(KeyCode.E))
    {
        HandleInteractionInput();
    }
}
```

**HandleInteractionInput()** - додай на початок:
```csharp
void HandleInteractionInput()
{
    if (Time.time - lastInteractionTime < interactionCooldown) return;
    
    // решта коду залишається без змін...
    lastInteractionTime = Time.time;
}
```

---

### 3. 💚 Ефекти лікування (3 хвилини)

**CameraEffects.cs** - замініть `PlayHealEffect()`:
```csharp
public void PlayHealEffect()
{
    if (healEffectCoroutine != null)
        StopCoroutine(healEffectCoroutine);
    
    healEffectCoroutine = StartCoroutine(HealEffectCoroutine());
}

private IEnumerator HealEffectCoroutine()
{
    Color originalColor = flashImage.color;
    Color healColor = new Color(0, 1, 0, 0.3f); // зелений
    
    // 3 пульсації
    for (int i = 0; i < 3; i++)
    {
        // Fade in
        float timer = 0f;
        while (timer < 0.2f)
        {
            timer += Time.deltaTime;
            flashImage.color = Color.Lerp(originalColor, healColor, timer / 0.2f);
            yield return null;
        }
        
        // Fade out
        timer = 0f;
        while (timer < 0.2f)
        {
            timer += Time.deltaTime;
            flashImage.color = Color.Lerp(healColor, originalColor, timer / 0.2f);
            yield return null;
        }
    }
    
    flashImage.color = originalColor;
}
```

---

### 4. 🛡️ Захист від спаму (2 хвилини)

**Вже зроблено** в кроці 2 - додали `interactionCooldown`

---

## ✅ Перевірка

1. **Відбій:** Стріляй - камера має трястися
2. **Взаємодія:** Відкрий Task Manager - FPS має бути стабільним
3. **Лікування:** Відновлюй здоров'я - зелені спалахи
4. **Спам:** Тицяй E швидко - має спрацьовувати з затримкою

## ⏱️ Загальний час: 10-15 хвилин

**Результат:** Виправлені найбільші проблеми гри без зламу архітектури.

---

🔥 **Після цього гра буде грати значно краще!**